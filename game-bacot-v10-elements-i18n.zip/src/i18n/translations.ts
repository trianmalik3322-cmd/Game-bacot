// 🌐 Translations untuk SandBox World
// 6 Bahasa: Indonesia, English, Spanish, Chinese, Japanese, Arabic

export type LanguageCode = 'id' | 'en' | 'es' | 'zh' | 'ja' | 'ar';

export interface LanguageInfo {
  code: LanguageCode;
  name: string;        // Nama bahasa di bahasa sendiri (native)
  englishName: string; // Nama bahasa di Inggris
  flag: string;        // Emoji flag
  rtl?: boolean;       // Right-to-left (buat Arabic)
}

export const LANGUAGES: LanguageInfo[] = [
  { code: 'id', name: 'Indonesia',  englishName: 'Indonesian', flag: '🇮🇩' },
  { code: 'en', name: 'English',    englishName: 'English',    flag: '🇬🇧' },
  { code: 'es', name: 'Español',    englishName: 'Spanish',    flag: '🇪🇸' },
  { code: 'zh', name: '中文',        englishName: 'Chinese',    flag: '🇨🇳' },
  { code: 'ja', name: '日本語',      englishName: 'Japanese',   flag: '🇯🇵' },
  { code: 'ar', name: 'العربية',    englishName: 'Arabic',     flag: '🇸🇦', rtl: true },
];

// Type buat semua translation keys (auto-complete + type safety)
export interface Translation {
  // === WELCOME / ONBOARDING ===
  welcome: {
    title: string;
    greeting: string;
    description: string;
    feature_physics: string;
    feature_physics_desc: string;
    feature_creatures: string;
    feature_creatures_desc: string;
    feature_seasons: string;
    feature_seasons_desc: string;
    feature_coins: string;
    feature_coins_desc: string;
    next: string;
    skip: string;
    start: string;
  };

  // === COMMON / UI ===
  common: {
    close: string;
    save: string;
    cancel: string;
    confirm: string;
    yes: string;
    no: string;
    ok: string;
    back: string;
    next: string;
    loading: string;
    error: string;
    success: string;
    buy: string;
    sell: string;
    locked: string;
    unlocked: string;
    coming_soon: string;
    free: string;
    premium: string;
  };

  // === GAME UI ===
  game: {
    spawned: string;
    points: string;
    brush: string;
    speed: string;
    pause: string;
    play: string;
    clear: string;
    reset: string;
    tap_to_change: string;
    auto_bot: string;
  };

  // === CATEGORIES ===
  categories: {
    basic: string;
    earth: string;
    weather: string;
    special: string;
    experimental: string;
    life: string;
    shop: string;
    auto: string;
  };

  // === SEASONS ===
  seasons: {
    title: string;
    spring: string;
    summer: string;
    autumn: string;
    winter: string;
    next_in: string;
  };

  // === SHOP ===
  shop: {
    title: string;
    title_full: string;
    your_coins: string;
    not_enough: string;
    owned: string;
    purchase: string;
    purchased: string;
    category_creatures: string;
    category_elements: string;
    category_powerups: string;
    category_premium: string;
    items_count: string;
    search_placeholder: string;
    no_items: string;
    consumable: string;
    badge_owned: string;
    super_active: string;
    premium_subtitle: string;
    super_premium_subtitle: string;
    new_badge: string;
    welcome_premium: string;
    welcome_super_premium: string;
    already_premium: string;
    already_super_premium: string;
  };

  // === SETTINGS ===
  settings: {
    title: string;
    language: string;
    language_desc: string;
    sound: string;
    sound_on: string;
    sound_off: string;
    volume: string;
    theme: string;
    map_size: string;
    fps: string;
    show_fps: string;
    notifications: string;
    install_app: string;
    install_desc: string;
    about: string;
    version: string;
    credits: string;
    reset_progress: string;
    reset_warning: string;
    tab_appearance: string;
    tab_season: string;
    tab_game: string;
    tab_map: string;
    tab_language: string;
    color_theme: string;
    preview: string;
    auto_season: string;
    auto_season_desc: string;
    current_season: string;
    pick_season_manual: string;
    season_speed: string;
    speed_slow: string;
    speed_normal: string;
    speed_fast: string;
    speed_super: string;
    sound_toggle_desc: string;
    test_sound: string;
    show_fps_desc: string;
    particle_glow: string;
    particle_glow_desc: string;
    game_info: string;
    game_info_text: string;
    keyboard_shortcuts: string;
    shortcut_play_pause: string;
    shortcut_clear: string;
    shortcut_shop: string;
    map_size_title: string;
    map_size_desc: string;
    map_normal: string;
    map_normal_desc: string;
    map_large: string;
    map_large_desc: string;
    map_super: string;
    map_super_desc: string;
    map_superpremium: string;
    map_superpremium_desc: string;
    badge_active: string;
    buy_first: string;
    premium_info: string;
    premium_info_desc: string;
    super_premium_info_desc: string;
    save_and_close: string;
    auto_detect_info: string;
  };

  // === ACHIEVEMENTS ===
  achievements: {
    title: string;
    unlocked: string;
    locked: string;
    progress: string;
    new_achievement: string;
    completion: string;
    modal_title: string;
    progress_status: string;
    tab_unlocked: string;
    tab_locked: string;
    done_badge: string;
    empty_title: string;
    empty_subtitle: string;
    secret_locked: string;
  };

  // === AUTO FARM ===
  autofarm: {
    title: string;
    enable: string;
    disable: string;
    speed: string;
    target: string;
    coins_per_min: string;
    status_active: string;
    status_paused: string;
    subtitle: string;
    status_on: string;
    status_off: string;
    btn_start: string;
    btn_stop: string;
    tab_settings: string;
    tab_stats: string;
    pick_element: string;
    spawn_speed: string;
    how_it_works: string;
    how_it_works_desc: string;
    total_coins: string;
    total_spawned_stat: string;
    coins_minute: string;
    coins_hour: string;
    progress_to: string;
    farming: string;
    not_active: string;
  };

  // === STATS ===
  stats: {
    title: string;
    total_spawned: string;
    total_coins: string;
    playtime: string;
    elements_discovered: string;
    creatures_seen: string;
    subtitle: string;
    spawn_per_min: string;
    coins_per_min: string;
    elements_tried: string;
    canvas_cleared: string;
    items_bought: string;
    fps: string;
    auto_farm_label: string;
    auto_farm_on: string;
    auto_farm_off: string;
    premium_label: string;
    premium_super: string;
    premium_active: string;
    premium_none: string;
    active_element: string;
    footer_tip: string;
  };

  // === SEASONS ===
  seasonsList: {
    spring: { name: string; description: string };
    summer: { name: string; description: string };
    autumn: { name: string; description: string };
    winter: { name: string; description: string };
  };

  // === ADMIN (kalau ada) ===
  admin: {
    title: string;
    access_denied: string;
    give_coins: string;
    unlock_all: string;
    reset_all: string;
    god_mode_active: string;
    manage_points: string;
    current_points: string;
    quick_add: string;
    total_spawned: string;
    premium_and_items: string;
    premium_status: string;
    items_purchased: string;
    game_control: string;
    pick_element_direct: string;
    cheat_codes: string;
    cheats_warning: string;
    log: string;
    admin_mode: string;
    edit: string;
    reset_points: string;
    active: string;
    inactive: string;
    activate: string;
    revoke: string;
    unlock_all_btn: string;
    items_count: string;
    set_points: string;
    set_total_spawned: string;
    close: string;
    log_admin_active: string;
    log_points_reset: string;
    log_premium_on: string;
    log_premium_off: string;
    log_unlock_all: string;
    log_spawned_set: string;
  };

  // === ACHIEVEMENT entries by ID ===
  achievementsList: {
    [key: string]: { title: string; desc: string };
  };

  // === TUTORIAL ===
  tutorial: {
    page_welcome: string;
    page_howto: string;
    page_creatures: string;
    desc_intro: string;
    desc_creatures: string;
    howto_click: string;
    howto_click_desc: string;
    howto_element: string;
    howto_element_desc: string;
    howto_brush: string;
    howto_brush_desc: string;
    howto_pause: string;
    howto_pause_desc: string;
    howto_settings: string;
    howto_settings_desc: string;
    creature_ant: string;
    creature_ant_desc: string;
    creature_fish: string;
    creature_fish_desc: string;
    creature_bird: string;
    creature_bird_desc: string;
    creature_worm: string;
    creature_worm_desc: string;
    creature_frog: string;
    creature_frog_desc: string;
    creature_crab: string;
    creature_crab_desc: string;
    creature_bee: string;
    creature_bee_desc: string;
    creature_mushroom: string;
    creature_mushroom_desc: string;
    start_playing: string;
    premium_element_locked: string;
    open_shop: string;
    tips: string;
  };
}

// ============================================
// 🇮🇩 INDONESIA (Default / Source language)
// ============================================
const id: Translation = {
  welcome: {
    title: 'SandBox World',
    greeting: '👋 Selamat Datang!',
    description: 'Game simulasi partikel fisika! Ada 40+ elemen, Makhluk Hidup, Shop, Musim, dan Premium!',
    feature_physics: 'Physics Sandbox',
    feature_physics_desc: 'Simulasi fisika real-time',
    feature_creatures: 'Makhluk Hidup',
    feature_creatures_desc: 'Ant, Fish, Bird, Frog...',
    feature_seasons: 'Sistem Musim',
    feature_seasons_desc: 'Semi, Panas, Gugur, Dingin',
    feature_coins: '10 blok = 1 poin',
    feature_coins_desc: 'Kumpulin & belanja!',
    next: 'Lanjut →',
    skip: 'Lewati',
    start: 'Mulai Main!',
  },
  common: {
    close: 'Tutup', save: 'Simpan', cancel: 'Batal', confirm: 'Konfirmasi',
    yes: 'Ya', no: 'Tidak', ok: 'OK', back: 'Kembali', next: 'Lanjut',
    loading: 'Memuat...', error: 'Error', success: 'Berhasil',
    buy: 'Beli', sell: 'Jual', locked: 'Terkunci', unlocked: 'Terbuka',
    coming_soon: 'Segera Hadir', free: 'Gratis', premium: 'Premium',
  },
  game: {
    spawned: 'dispawn', points: 'poin', brush: 'Kuas', speed: 'Kecepatan',
    pause: 'Jeda', play: 'Main', clear: 'Bersihkan', reset: 'Reset',
    tap_to_change: 'Tap ganti', auto_bot: 'Auto Bot',
  },
  categories: {
    basic: 'Dasar', earth: 'Bumi', weather: 'Cuaca', special: 'Spesial',
    experimental: 'Eksperimen', life: 'Makhluk', shop: 'Toko', auto: 'Otomatis',
  },
  seasons: {
    title: 'Musim', spring: 'Semi', summer: 'Panas', autumn: 'Gugur',
    winter: 'Dingin', next_in: 'Berikutnya dalam',
  },
    shop: {
    title: '🛍️ Toko', title_full: 'SandBox Shop', your_coins: 'Poin Kamu', not_enough: 'Poin kurang!',
    owned: 'Dimiliki', purchase: 'Beli', purchased: 'Dibeli!',
    category_creatures: 'Makhluk', category_elements: 'Elemen',
    category_powerups: 'Power-up', category_premium: 'Premium 👑',
    items_count: 'item', search_placeholder: '🔍 Cari item...',
    no_items: '😕 Tidak ada item ditemukan',
    consumable: 'KONSUMABEL', badge_owned: '✅ DIMILIKI',
    super_active: 'SuperPremium Aktif — Semua fitur terbuka!',
    premium_subtitle: '20+ perks eksklusif + semua elemen unlock!',
    super_premium_subtitle: '25+ perks • Map Raksasa • 10x Point Permanen!',
    new_badge: 'BARU',
    welcome_premium: '👑 Selamat datang di Premium! +200 bonus poin!',
    welcome_super_premium: '💎 SELAMAT DATANG DI SUPERPREMIUM! +5000 bonus poin! 🚀',
    already_premium: 'Sudah Premium! 👑',
    already_super_premium: 'Sudah SuperPremium! 💎',
  },
  settings: {
    title: '⚙️ Pengaturan', language: 'Bahasa',
    language_desc: 'Pilih bahasa game',
    sound: 'Suara', sound_on: 'Aktif', sound_off: 'Mati', volume: 'Volume',
    theme: 'Tema', map_size: 'Ukuran Map', fps: 'FPS', show_fps: 'Tampilkan FPS',
    notifications: 'Notifikasi', install_app: 'Install Aplikasi',
    install_desc: 'Install sebagai aplikasi di perangkat',
    about: 'Tentang', version: 'Versi', credits: 'Kredit',
    reset_progress: 'Reset Progress', reset_warning: 'Yakin? Semua progress akan hilang!',
  
    tab_appearance: '🎨 Tampilan', tab_season: '🌸 Musim', tab_game: '⚙️ Game',
    tab_map: '🗺️ Map', tab_language: '🌐 Bahasa',
    color_theme: '🎨 Warna Tema', preview: 'Preview',
    auto_season: 'Auto Musim', auto_season_desc: 'Musim berganti otomatis',
    current_season: 'Musim Sekarang', pick_season_manual: 'Pilih Musim Manual',
    season_speed: '⚡ Kecepatan Musim',
    speed_slow: 'Lambat', speed_normal: 'Normal', speed_fast: 'Cepat', speed_super: 'Super',
    sound_toggle_desc: 'Aktifkan/matikan efek suara',
    test_sound: 'Tes Suara',
    show_fps_desc: 'Lihat performa game di layar',
    particle_glow: '✨ Particle Glow', particle_glow_desc: 'Efek cahaya partikel (butuh GPU)',
    game_info: '💡 Info Game',
    game_info_text: 'SandBox World v3.0 — 40+ elemen, makhluk hidup, musim, shop, dan premium system!',
    keyboard_shortcuts: 'Keyboard Shortcuts',
    shortcut_play_pause: 'Main / Jeda', shortcut_clear: 'Bersihkan Canvas', shortcut_shop: 'Buka Toko',
    map_size_title: '🗺️ Ukuran Map',
    map_size_desc: 'Beli ukuran map di Shop untuk unlock. Kamu bisa balik ke ukuran lebih kecil kapanpun di sini!',
    map_normal: 'Normal', map_normal_desc: 'Ukuran default — ringan & cepat di semua HP',
    map_large: 'Besar (1.5x)', map_large_desc: 'Perlu item "Besarkan Map" dari Shop 🛍️',
    map_super: 'Super Gede (2x)', map_super_desc: 'Perlu item "Map Super Gede" dari Shop 🛍️',
    map_superpremium: 'SuperPremium (5x)', map_superpremium_desc: 'MEGA RAKSASA setara luas negara! Perlu SuperPremium 💎',
    badge_active: 'AKTIF', buy_first: 'Beli dulu',
    premium_info: '👑 Premium', premium_info_desc: 'Unlock Map Besar & Super Gede. Beli di Shop → Spesial',
    super_premium_info_desc: 'Unlock Map SuperPremium RAKSASA. Eksklusif!',
    save_and_close: '✅ Simpan & Tutup',
    auto_detect_info: 'Auto-detect: Bahasa otomatis ngikut HP/browser kamu pertama kali buka game.',
  },
    achievements: {
    title: '🏆 Pencapaian', unlocked: 'Terbuka', locked: 'Terkunci',
    progress: 'Progress', new_achievement: '🏆 Pencapaian Baru!', completion: 'Selesai',
    modal_title: 'Pencapaian', progress_status: 'terbuka • {progress}% selesai',
    tab_unlocked: '✅ Terbuka', tab_locked: '🔒 Terkunci',
    done_badge: '✅ Selesai',
    empty_title: 'Belum ada pencapaian yang terbuka!',
    empty_subtitle: 'Main dulu yuk...',
    secret_locked: 'Rahasia... mainkan terus untuk membuka!',
  },
    autofarm: {
    title: 'Auto Farm', enable: 'Aktifkan', disable: 'Matikan',
    speed: 'Kecepatan', target: 'Target', coins_per_min: 'koin/menit',
    status_active: 'Aktif', status_paused: 'Berhenti',
    subtitle: 'Spawn otomatis & kumpulin koin!',
    status_on: '🟢 AUTO FARM AKTIF', status_off: '⚫ AUTO FARM MATI',
    btn_start: '▶ MULAI', btn_stop: '⏹ STOP',
    tab_settings: '⚙️ Pengaturan', tab_stats: '📊 Statistik',
    pick_element: '🎯 Pilih Elemen yang Di-Spawn',
    spawn_speed: '⚡ Kecepatan Spawn',
    how_it_works: 'Cara Kerja Auto Farm',
    how_it_works_desc: 'Auto Farm otomatis spawn elemen di canvas setiap beberapa detik. Setiap 10 blok yang di-spawn = 1 koin. Makin cepet speed → makin banyak koin!',
    total_coins: 'Total Koin', total_spawned_stat: 'Total Dispawn',
    coins_minute: 'Koin / Menit', coins_hour: 'Koin / Jam',
    progress_to: 'Progress ke 1000 koin',
    farming: '🟢 Sedang farming...', not_active: '⚫ Farm belum aktif',
  },
    stats: {
    title: '📊 Statistik Game', total_spawned: 'Total Dispawn',
    total_coins: 'Total Poin', playtime: 'Waktu Main',
    elements_discovered: 'Elemen Ditemukan', creatures_seen: 'Makhluk Dilihat',
    subtitle: 'Live stats kamu!',
    spawn_per_min: 'Dispawn/Menit', coins_per_min: 'Poin/Menit',
    elements_tried: 'Elemen Dicoba', canvas_cleared: 'Canvas Dibersihkan',
    items_bought: 'Item Dibeli', fps: 'FPS',
    auto_farm_label: 'Auto Farm', auto_farm_on: 'ON', auto_farm_off: 'OFF',
    premium_label: 'Premium', premium_super: '💎 Super',
    premium_active: '👑 Aktif', premium_none: '❌ Belum',
    active_element: 'Elemen Aktif',
    footer_tip: '💡 Terus main untuk unlock pencapaian & kumpulin lebih banyak poin!',
  },
  seasonsList: {
    spring: { name: 'Semi',  description: 'Hujan ringan & tanaman tumbuh subur!' },
    summer: { name: 'Panas', description: 'Terik! Api menyebar lebih cepat, air menguap!' },
    autumn: { name: 'Gugur', description: 'Daun berguguran dari langit dengan angin!' },
    winter: { name: 'Dingin',description: 'Salju turun deras, air membeku!' },
  },
    tutorial: {
    page_welcome: '👋 Selamat Datang!',
    page_howto: '🖱️ Cara Main',
    page_creatures: '🐾 Makhluk Hidup',
    desc_intro: 'Game simulasi partikel fisika! Ada 40+ elemen, Makhluk Hidup, Shop, Musim, dan Premium!',
    desc_creatures: 'Elemen hidup yang bergerak sendiri!',
    howto_click: 'Klik / Sentuh & Geser',
    howto_click_desc: 'Tahan di canvas lalu geser untuk menggambar!',
    howto_element: 'Pilih Elemen',
    howto_element_desc: 'Tap tombol elemen di bawah (mobile) atau panel kiri',
    howto_brush: 'Ukuran Brush',
    howto_brush_desc: 'Pilih 1, 3, 5, atau 8 untuk kuas berbeda',
    howto_pause: 'Pause / Play',
    howto_pause_desc: 'Stop/lanjutkan simulasi kapanpun',
    howto_settings: 'Pengaturan',
    howto_settings_desc: 'Ganti tema warna & atur musim di Settings',
    creature_ant: '🐜 Semut', creature_ant_desc: 'Bergerak ke kiri-kanan, mati kena api',
    creature_fish: '🐟 Ikan', creature_fish_desc: 'Berenang di dalam air',
    creature_bird: '🐦 Burung', creature_bird_desc: 'Terbang bebas ke atas',
    creature_worm: '🪱 Cacing', creature_worm_desc: 'Menggali pasir & tanah',
    creature_frog: '🐸 Katak', creature_frog_desc: 'Melompat-lompat, suka air',
    creature_crab: '🦀 Kepiting', creature_crab_desc: 'Bergerak menyamping di pasir',
    creature_bee: '🐝 Lebah', creature_bee_desc: 'Terbang bebas, hasilkan madu!',
    creature_mushroom: '🍄 Jamur', creature_mushroom_desc: 'Tumbuh di tanah lembab',
    start_playing: '🎮 Mulai!',
    premium_element_locked: 'Elemen premium! Beli dulu di Shop.',
    open_shop: 'Buka Shop',
    tips: 'Tips',
  },
    admin: {
    title: 'Admin Panel', access_denied: 'Akses Ditolak',
    give_coins: 'Beri Poin', unlock_all: 'Buka Semua', reset_all: 'Reset Semua',
    god_mode_active: '🔐 God Mode Aktif',
    manage_points: '💰 Kelola Poin', current_points: 'POIN SAAT INI',
    quick_add: 'TAMBAH CEPAT:', total_spawned: '🎯 Total Dispawn',
    premium_and_items: '👑 Premium & Item', premium_status: 'STATUS PREMIUM',
    items_purchased: 'ITEM TERBELI', game_control: '🎮 Kontrol Game',
    pick_element_direct: '⚗️ Pilih Elemen Langsung', cheat_codes: '🎯 Kode Curang',
    cheats_warning: '⚠️ Cheat ini hanya untuk testing!',
    log: '📋 Log', admin_mode: '⚡ Mode Admin',
  
    edit: '✏️ Edit', reset_points: '🗑️ Reset Poin ke 0',
    active: '✅ Aktif', inactive: '❌ Tidak Aktif',
    activate: '✅ Aktifkan', revoke: '❌ Cabut',
    unlock_all_btn: '🔓 Buka Semua', items_count: 'item',
    set_points: '💰 Atur Poin', set_total_spawned: '🎯 Atur Total Dispawn',
    close: 'Tutup',
    log_admin_active: '🔐 Admin Panel Aktif!',
    log_points_reset: '💰 Poin di-reset ke 0',
    log_premium_on: '👑 Premium diaktifkan',
    log_premium_off: '👑 Premium dicabut',
    log_unlock_all: '🔓 Semua item dibuka!',
    log_spawned_set: '🎯 Atur dispawn ke',
  },
  achievementsList: {
    first_block: { title: 'Langkah Pertama', desc: 'Spawn blok pertama!' },
    hundred: { title: 'Seratus!', desc: 'Spawn 100 blok' },
    thousand: { title: 'Seribu!', desc: 'Spawn 1.000 blok' },
    tenk: { title: 'Sepuluh Ribu!', desc: 'Spawn 10.000 blok' },
    hundredk: { title: 'Seratus Ribu!', desc: 'Spawn 100.000 blok!' },
    millionaire: { title: 'Jutawan Blok!', desc: 'Spawn 1 juta blok!' },
    rich: { title: 'Tajir Melintir', desc: 'Kumpulin 1.000 poin' },
    super_rich: { title: 'Sultan!', desc: 'Kumpulin 10.000 poin' },
    mega_rich: { title: 'Konglomerat!', desc: 'Kumpulin 100.000 poin' },
    premium: { title: 'Royalti', desc: 'Beli Premium!' },
    superpremium: { title: 'SuperPremium!', desc: 'Beli SuperPremium!' },
    explorer: { title: 'Penjelajah', desc: 'Coba 10 elemen berbeda' },
    collector: { title: 'Kolektor', desc: 'Coba 25 elemen berbeda' },
    master: { title: 'Master Elemen', desc: 'Coba 50 elemen berbeda' },
    shopper: { title: 'Shopaholic', desc: 'Beli 5 item di Shop' },
    big_shopper: { title: 'Big Spender', desc: 'Beli 20 item di Shop' },
    cleaner: { title: 'Bersih-Bersih', desc: 'Clear canvas 5x' },
    destructive: { title: 'Destruktif!', desc: 'Clear canvas 20x' },
    speed_demon: { title: 'Speed Demon', desc: 'Pakai speed 5x atau lebih' },
    ultra_speed: { title: 'Ultra Speed', desc: 'Pakai speed 10x atau lebih' },
    farmer: { title: 'Auto Farmer', desc: 'Aktifkan Auto Farm' },
    seasonal: { title: 'Pengganti Musim', desc: 'Ganti musim 4x' },
    veteran: { title: 'Veteran', desc: 'Main selama 30 menit' },
    legend: { title: 'Legenda!', desc: 'Main selama 2 jam' },
    secret_admin: { title: '???', desc: 'Temukan panel tersembunyi' },
  },
};

// ============================================
// 🇬🇧 ENGLISH
// ============================================
const en: Translation = {
  welcome: {
    title: 'SandBox World',
    greeting: '👋 Welcome!',
    description: 'Physics particle simulation game! 40+ elements, Living Creatures, Shop, Seasons, and Premium!',
    feature_physics: 'Physics Sandbox',
    feature_physics_desc: 'Real-time physics simulation',
    feature_creatures: 'Living Creatures',
    feature_creatures_desc: 'Ant, Fish, Bird, Frog...',
    feature_seasons: 'Season System',
    feature_seasons_desc: 'Spring, Summer, Autumn, Winter',
    feature_coins: '10 blocks = 1 coin',
    feature_coins_desc: 'Collect & shop!',
    next: 'Next →',
    skip: 'Skip',
    start: 'Start Playing!',
  },
  common: {
    close: 'Close', save: 'Save', cancel: 'Cancel', confirm: 'Confirm',
    yes: 'Yes', no: 'No', ok: 'OK', back: 'Back', next: 'Next',
    loading: 'Loading...', error: 'Error', success: 'Success',
    buy: 'Buy', sell: 'Sell', locked: 'Locked', unlocked: 'Unlocked',
    coming_soon: 'Coming Soon', free: 'Free', premium: 'Premium',
  },
  game: {
    spawned: 'spawned', points: 'points', brush: 'Brush', speed: 'Speed',
    pause: 'Pause', play: 'Play', clear: 'Clear', reset: 'Reset',
    tap_to_change: 'Tap to change', auto_bot: 'Auto Bot',
  },
  categories: {
    basic: 'Basic', earth: 'Earth', weather: 'Weather', special: 'Special',
    experimental: 'Experimental', life: 'Life', shop: 'Shop', auto: 'Auto',
  },
  seasons: {
    title: 'Season', spring: 'Spring', summer: 'Summer', autumn: 'Autumn',
    winter: 'Winter', next_in: 'Next in',
  },
    shop: {
    title: '🛍️ Shop', title_full: 'SandBox Shop', your_coins: 'Your Coins', not_enough: 'Not enough coins!',
    owned: 'Owned', purchase: 'Buy', purchased: 'Purchased!',
    category_creatures: 'Creatures', category_elements: 'Elements',
    category_powerups: 'Power-ups', category_premium: 'Premium 👑',
    items_count: 'items', search_placeholder: '🔍 Search items...',
    no_items: '😕 No items found',
    consumable: 'CONSUMABLE', badge_owned: '✅ OWNED',
    super_active: 'SuperPremium Active — All features unlocked!',
    premium_subtitle: '20+ exclusive perks + all elements unlock!',
    super_premium_subtitle: '25+ perks • Giant Map • 10x Permanent Points!',
    new_badge: 'NEW',
    welcome_premium: '👑 Welcome to Premium! +200 bonus points!',
    welcome_super_premium: '💎 WELCOME TO SUPERPREMIUM! +5000 bonus points! 🚀',
    already_premium: 'Already Premium! 👑',
    already_super_premium: 'Already SuperPremium! 💎',
  },
  settings: {
    title: '⚙️ Settings', language: 'Language',
    language_desc: 'Choose game language',
    sound: 'Sound', sound_on: 'On', sound_off: 'Off', volume: 'Volume',
    theme: 'Theme', map_size: 'Map Size', fps: 'FPS', show_fps: 'Show FPS',
    notifications: 'Notifications', install_app: 'Install App',
    install_desc: 'Install as app on your device',
    about: 'About', version: 'Version', credits: 'Credits',
    reset_progress: 'Reset Progress', reset_warning: 'Are you sure? All progress will be lost!',
  
    tab_appearance: '🎨 Appearance', tab_season: '🌸 Season', tab_game: '⚙️ Game',
    tab_map: '🗺️ Map', tab_language: '🌐 Language',
    color_theme: '🎨 Color Theme', preview: 'Preview',
    auto_season: 'Auto Season', auto_season_desc: 'Seasons change automatically',
    current_season: 'Current Season', pick_season_manual: 'Pick Season Manually',
    season_speed: '⚡ Season Speed',
    speed_slow: 'Slow', speed_normal: 'Normal', speed_fast: 'Fast', speed_super: 'Super',
    sound_toggle_desc: 'Turn sound effects on/off',
    test_sound: 'Test Sound',
    show_fps_desc: 'See game performance on screen',
    particle_glow: '✨ Particle Glow', particle_glow_desc: 'Particle light effect (needs GPU)',
    game_info: '💡 Game Info',
    game_info_text: 'SandBox World v3.0 — 40+ elements, living creatures, seasons, shop, and premium system!',
    keyboard_shortcuts: 'Keyboard Shortcuts',
    shortcut_play_pause: 'Play / Pause', shortcut_clear: 'Clear Canvas', shortcut_shop: 'Open Shop',
    map_size_title: '🗺️ Map Size',
    map_size_desc: 'Buy map sizes in Shop to unlock. You can switch back to smaller sizes anytime here!',
    map_normal: 'Normal', map_normal_desc: 'Default size — light & fast on all phones',
    map_large: 'Large (1.5x)', map_large_desc: 'Needs item "Enlarge Map" from Shop 🛍️',
    map_super: 'Super Big (2x)', map_super_desc: 'Needs item "Super Big Map" from Shop 🛍️',
    map_superpremium: 'SuperPremium (5x)', map_superpremium_desc: 'MEGA GIANT, country-sized! Needs SuperPremium 💎',
    badge_active: 'ACTIVE', buy_first: 'Buy first',
    premium_info: '👑 Premium', premium_info_desc: 'Unlock Large & Super Big Map. Buy in Shop → Special',
    super_premium_info_desc: 'Unlock SuperPremium GIANT Map. Exclusive!',
    save_and_close: '✅ Save & Close',
    auto_detect_info: 'Auto-detect: Language automatically follows your phone/browser on first launch.',
  },
    achievements: {
    title: '🏆 Achievements', unlocked: 'Unlocked', locked: 'Locked',
    progress: 'Progress', new_achievement: '🏆 New Achievement!', completion: 'Complete',
    modal_title: 'Achievements', progress_status: 'unlocked • {progress}% complete',
    tab_unlocked: '✅ Unlocked', tab_locked: '🔒 Locked',
    done_badge: '✅ Done',
    empty_title: 'No achievements unlocked yet!',
    empty_subtitle: "Let's play first...",
    secret_locked: 'Secret... keep playing to unlock!',
  },
    autofarm: {
    title: 'Auto Farm', enable: 'Enable', disable: 'Disable',
    speed: 'Speed', target: 'Target', coins_per_min: 'coins/min',
    status_active: 'Active', status_paused: 'Paused',
    subtitle: 'Auto-spawn & collect coins!',
    status_on: '🟢 AUTO FARM ON', status_off: '⚫ AUTO FARM OFF',
    btn_start: '▶ START', btn_stop: '⏹ STOP',
    tab_settings: '⚙️ Settings', tab_stats: '📊 Stats',
    pick_element: '🎯 Pick Element to Spawn',
    spawn_speed: '⚡ Spawn Speed',
    how_it_works: 'How Auto Farm Works',
    how_it_works_desc: 'Auto Farm automatically spawns elements on canvas every few seconds. Every 10 blocks spawned = 1 coin. Faster speed → more coins!',
    total_coins: 'Total Coins', total_spawned_stat: 'Total Spawned',
    coins_minute: 'Coins / Minute', coins_hour: 'Coins / Hour',
    progress_to: 'Progress to 1000 coins',
    farming: '🟢 Farming...', not_active: '⚫ Farm not active',
  },
    stats: {
    title: '📊 Game Stats', total_spawned: 'Total Spawned',
    total_coins: 'Total Coins', playtime: 'Playtime',
    elements_discovered: 'Elements Discovered', creatures_seen: 'Creatures Seen',
    subtitle: 'Your live stats!',
    spawn_per_min: 'Spawn/Min', coins_per_min: 'Coins/Min',
    elements_tried: 'Elements Tried', canvas_cleared: 'Canvas Cleared',
    items_bought: 'Items Bought', fps: 'FPS',
    auto_farm_label: 'Auto Farm', auto_farm_on: 'ON', auto_farm_off: 'OFF',
    premium_label: 'Premium', premium_super: '💎 Super',
    premium_active: '👑 Active', premium_none: '❌ None',
    active_element: 'Active Element',
    footer_tip: '💡 Keep playing to unlock achievements & collect more coins!',
  },
  seasonsList: {
    spring: { name: 'Spring', description: 'Light rain & plants flourish!' },
    summer: { name: 'Summer', description: 'Scorching! Fire spreads faster, water evaporates!' },
    autumn: { name: 'Autumn', description: 'Leaves fall from the sky with the wind!' },
    winter: { name: 'Winter', description: 'Heavy snow falls, water freezes!' },
  },
    tutorial: {
    page_welcome: '👋 Welcome!',
    page_howto: '🖱️ How to Play',
    page_creatures: '🐾 Living Creatures',
    desc_intro: 'Physics particle simulation game! 40+ elements, Living Creatures, Shop, Seasons, and Premium!',
    desc_creatures: 'Living elements that move by themselves!',
    howto_click: 'Click / Touch & Drag',
    howto_click_desc: 'Hold on canvas then drag to draw!',
    howto_element: 'Pick Element',
    howto_element_desc: 'Tap element button below (mobile) or left panel',
    howto_brush: 'Brush Size',
    howto_brush_desc: 'Choose 1, 3, 5, or 8 for different brushes',
    howto_pause: 'Pause / Play',
    howto_pause_desc: 'Stop/resume simulation anytime',
    howto_settings: 'Settings',
    howto_settings_desc: 'Change color theme & season in Settings',
    creature_ant: '🐜 Ant', creature_ant_desc: 'Walks left-right, dies in fire',
    creature_fish: '🐟 Fish', creature_fish_desc: 'Swims inside water',
    creature_bird: '🐦 Bird', creature_bird_desc: 'Flies freely upward',
    creature_worm: '🪱 Worm', creature_worm_desc: 'Burrows in sand & dirt',
    creature_frog: '🐸 Frog', creature_frog_desc: 'Jumps around, loves water',
    creature_crab: '🦀 Crab', creature_crab_desc: 'Moves sideways on sand',
    creature_bee: '🐝 Bee', creature_bee_desc: 'Flies freely, makes honey!',
    creature_mushroom: '🍄 Mushroom', creature_mushroom_desc: 'Grows on moist soil',
    start_playing: '🎮 Play!',
    premium_element_locked: 'Premium element! Buy in Shop first.',
    open_shop: 'Open Shop',
    tips: 'Tips',
  },
    admin: {
    title: 'Admin Panel', access_denied: 'Access Denied',
    give_coins: 'Give Coins', unlock_all: 'Unlock All', reset_all: 'Reset All',
    god_mode_active: '🔐 God Mode Active',
    manage_points: '💰 Manage Points', current_points: 'CURRENT POINTS',
    quick_add: 'QUICK ADD:', total_spawned: '🎯 Total Spawned',
    premium_and_items: '👑 Premium & Items', premium_status: 'PREMIUM STATUS',
    items_purchased: 'ITEMS PURCHASED', game_control: '🎮 Game Control',
    pick_element_direct: '⚗️ Pick Element Direct', cheat_codes: '🎯 Cheat Codes',
    cheats_warning: '⚠️ These cheats are for testing only!',
    log: '📋 Log', admin_mode: '⚡ Admin Mode',
  
    edit: '✏️ Edit', reset_points: '🗑️ Reset Points to 0',
    active: '✅ Active', inactive: '❌ Inactive',
    activate: '✅ Activate', revoke: '❌ Revoke',
    unlock_all_btn: '🔓 Unlock All', items_count: 'items',
    set_points: '💰 Set Points', set_total_spawned: '🎯 Set Total Spawned',
    close: 'Close',
    log_admin_active: '🔐 Admin Panel Active!',
    log_points_reset: '💰 Points reset to 0',
    log_premium_on: '👑 Premium activated',
    log_premium_off: '👑 Premium revoked',
    log_unlock_all: '🔓 All items unlocked!',
    log_spawned_set: '🎯 Set spawned to',
  },
  achievementsList: {
    first_block: { title: 'First Step', desc: 'Spawn first block!' },
    hundred: { title: 'Hundred!', desc: 'Spawn 100 blocks' },
    thousand: { title: 'Thousand!', desc: 'Spawn 1,000 blocks' },
    tenk: { title: 'Ten Thousand!', desc: 'Spawn 10,000 blocks' },
    hundredk: { title: 'Hundred Thousand!', desc: 'Spawn 100,000 blocks!' },
    millionaire: { title: 'Block Millionaire!', desc: 'Spawn 1 million blocks!' },
    rich: { title: 'Wealthy', desc: 'Collect 1,000 points' },
    super_rich: { title: 'Sultan!', desc: 'Collect 10,000 points' },
    mega_rich: { title: 'Tycoon!', desc: 'Collect 100,000 points' },
    premium: { title: 'Royalty', desc: 'Buy Premium!' },
    superpremium: { title: 'SuperPremium!', desc: 'Buy SuperPremium!' },
    explorer: { title: 'Explorer', desc: 'Try 10 different elements' },
    collector: { title: 'Collector', desc: 'Try 25 different elements' },
    master: { title: 'Element Master', desc: 'Try 50 different elements' },
    shopper: { title: 'Shopaholic', desc: 'Buy 5 items in Shop' },
    big_shopper: { title: 'Big Spender', desc: 'Buy 20 items in Shop' },
    cleaner: { title: 'Cleaner', desc: 'Clear canvas 5x' },
    destructive: { title: 'Destructive!', desc: 'Clear canvas 20x' },
    speed_demon: { title: 'Speed Demon', desc: 'Use speed 5x or more' },
    ultra_speed: { title: 'Ultra Speed', desc: 'Use speed 10x or more' },
    farmer: { title: 'Auto Farmer', desc: 'Enable Auto Farm' },
    seasonal: { title: 'Season Changer', desc: 'Change seasons 4x' },
    veteran: { title: 'Veteran', desc: 'Play for 30 minutes' },
    legend: { title: 'Legend!', desc: 'Play for 2 hours' },
    secret_admin: { title: '???', desc: 'Find the hidden panel' },
  },
};

// ============================================
// 🇪🇸 ESPAÑOL (Spanish)
// ============================================
const es: Translation = {
  welcome: {
    title: 'SandBox World',
    greeting: '👋 ¡Bienvenido!',
    description: '¡Juego de simulación de partículas físicas! 40+ elementos, Criaturas Vivas, Tienda, Estaciones y Premium!',
    feature_physics: 'Sandbox de Física',
    feature_physics_desc: 'Simulación física en tiempo real',
    feature_creatures: 'Criaturas Vivas',
    feature_creatures_desc: 'Hormiga, Pez, Pájaro, Rana...',
    feature_seasons: 'Sistema de Estaciones',
    feature_seasons_desc: 'Primavera, Verano, Otoño, Invierno',
    feature_coins: '10 bloques = 1 moneda',
    feature_coins_desc: '¡Recolecta y compra!',
    next: 'Siguiente →',
    skip: 'Saltar',
    start: '¡Jugar!',
  },
  common: {
    close: 'Cerrar', save: 'Guardar', cancel: 'Cancelar', confirm: 'Confirmar',
    yes: 'Sí', no: 'No', ok: 'OK', back: 'Atrás', next: 'Siguiente',
    loading: 'Cargando...', error: 'Error', success: 'Éxito',
    buy: 'Comprar', sell: 'Vender', locked: 'Bloqueado', unlocked: 'Desbloqueado',
    coming_soon: 'Próximamente', free: 'Gratis', premium: 'Premium',
  },
  game: {
    spawned: 'creados', points: 'puntos', brush: 'Pincel', speed: 'Velocidad',
    pause: 'Pausa', play: 'Jugar', clear: 'Limpiar', reset: 'Reiniciar',
    tap_to_change: 'Tocar para cambiar', auto_bot: 'Auto Bot',
  },
  categories: {
    basic: 'Básico', earth: 'Tierra', weather: 'Clima', special: 'Especial',
    experimental: 'Experimental', life: 'Vida', shop: 'Tienda', auto: 'Auto',
  },
  seasons: {
    title: 'Estación', spring: 'Primavera', summer: 'Verano', autumn: 'Otoño',
    winter: 'Invierno', next_in: 'Siguiente en',
  },
    shop: {
    title: '🛍️ Tienda', title_full: 'Tienda SandBox', your_coins: 'Tus Monedas', not_enough: '¡Monedas insuficientes!',
    owned: 'Adquirido', purchase: 'Comprar', purchased: '¡Comprado!',
    category_creatures: 'Criaturas', category_elements: 'Elementos',
    category_powerups: 'Mejoras', category_premium: 'Premium 👑',
    items_count: 'artículos', search_placeholder: '🔍 Buscar artículos...',
    no_items: '😕 No se encontraron artículos',
    consumable: 'CONSUMIBLE', badge_owned: '✅ ADQUIRIDO',
    super_active: 'SuperPremium Activo — ¡Todas las funciones desbloqueadas!',
    premium_subtitle: '¡20+ ventajas exclusivas + todos los elementos!',
    super_premium_subtitle: '25+ ventajas • Mapa Gigante • ¡10x Puntos Permanentes!',
    new_badge: 'NUEVO',
    welcome_premium: '👑 ¡Bienvenido a Premium! ¡+200 puntos de bonificación!',
    welcome_super_premium: '💎 ¡BIENVENIDO A SUPERPREMIUM! ¡+5000 puntos! 🚀',
    already_premium: '¡Ya tienes Premium! 👑',
    already_super_premium: '¡Ya tienes SuperPremium! 💎',
  },
  settings: {
    title: '⚙️ Ajustes', language: 'Idioma',
    language_desc: 'Elige el idioma del juego',
    sound: 'Sonido', sound_on: 'Activado', sound_off: 'Desactivado', volume: 'Volumen',
    theme: 'Tema', map_size: 'Tamaño del Mapa', fps: 'FPS', show_fps: 'Mostrar FPS',
    notifications: 'Notificaciones', install_app: 'Instalar App',
    install_desc: 'Instalar como aplicación en tu dispositivo',
    about: 'Acerca de', version: 'Versión', credits: 'Créditos',
    reset_progress: 'Reiniciar Progreso', reset_warning: '¿Seguro? ¡Se perderá todo el progreso!',
  
    tab_appearance: '🎨 Apariencia', tab_season: '🌸 Estación', tab_game: '⚙️ Juego',
    tab_map: '🗺️ Mapa', tab_language: '🌐 Idioma',
    color_theme: '🎨 Tema de Color', preview: 'Vista Previa',
    auto_season: 'Estación Automática', auto_season_desc: 'Las estaciones cambian automáticamente',
    current_season: 'Estación Actual', pick_season_manual: 'Elige Estación Manualmente',
    season_speed: '⚡ Velocidad de Estación',
    speed_slow: 'Lento', speed_normal: 'Normal', speed_fast: 'Rápido', speed_super: 'Super',
    sound_toggle_desc: 'Activar/desactivar efectos de sonido',
    test_sound: 'Probar Sonido',
    show_fps_desc: 'Ver rendimiento del juego en pantalla',
    particle_glow: '✨ Brillo de Partículas', particle_glow_desc: 'Efecto de luz de partículas (necesita GPU)',
    game_info: '💡 Info del Juego',
    game_info_text: 'SandBox World v3.0 — 40+ elementos, criaturas vivas, estaciones, tienda y sistema premium!',
    keyboard_shortcuts: 'Atajos de Teclado',
    shortcut_play_pause: 'Jugar / Pausa', shortcut_clear: 'Limpiar Lienzo', shortcut_shop: 'Abrir Tienda',
    map_size_title: '🗺️ Tamaño del Mapa',
    map_size_desc: 'Compra tamaños de mapa en Tienda para desbloquear. ¡Puedes volver a tamaños más pequeños cuando quieras!',
    map_normal: 'Normal', map_normal_desc: 'Tamaño por defecto — ligero y rápido en todos los móviles',
    map_large: 'Grande (1.5x)', map_large_desc: 'Necesita "Agrandar Mapa" de Tienda 🛍️',
    map_super: 'Súper Grande (2x)', map_super_desc: 'Necesita "Mapa Súper Grande" de Tienda 🛍️',
    map_superpremium: 'SuperPremium (5x)', map_superpremium_desc: '¡MEGA GIGANTE del tamaño de un país! Necesita SuperPremium 💎',
    badge_active: 'ACTIVO', buy_first: 'Compra primero',
    premium_info: '👑 Premium', premium_info_desc: 'Desbloquea Mapa Grande y Súper Grande. Compra en Tienda → Especial',
    super_premium_info_desc: 'Desbloquea Mapa SuperPremium GIGANTE. ¡Exclusivo!',
    save_and_close: '✅ Guardar y Cerrar',
    auto_detect_info: 'Auto-detección: El idioma sigue automáticamente tu móvil/navegador al abrir el juego por primera vez.',
  },
    achievements: {
    title: '🏆 Logros', unlocked: 'Desbloqueado', locked: 'Bloqueado',
    progress: 'Progreso', new_achievement: '🏆 ¡Nuevo Logro!', completion: 'Completo',
    modal_title: 'Logros', progress_status: 'desbloqueados • {progress}% completo',
    tab_unlocked: '✅ Desbloqueados', tab_locked: '🔒 Bloqueados',
    done_badge: '✅ Hecho',
    empty_title: '¡Aún no hay logros desbloqueados!',
    empty_subtitle: 'Juega primero...',
    secret_locked: 'Secreto... ¡sigue jugando para desbloquear!',
  },
    autofarm: {
    title: 'Auto Farm', enable: 'Activar', disable: 'Desactivar',
    speed: 'Velocidad', target: 'Objetivo', coins_per_min: 'monedas/min',
    status_active: 'Activo', status_paused: 'Pausado',
    subtitle: '¡Generación automática y recolección de monedas!',
    status_on: '🟢 AUTO FARM ACTIVO', status_off: '⚫ AUTO FARM INACTIVO',
    btn_start: '▶ INICIAR', btn_stop: '⏹ DETENER',
    tab_settings: '⚙️ Ajustes', tab_stats: '📊 Estadísticas',
    pick_element: '🎯 Elige Elemento a Generar',
    spawn_speed: '⚡ Velocidad de Generación',
    how_it_works: 'Cómo Funciona Auto Farm',
    how_it_works_desc: 'Auto Farm genera elementos en el lienzo cada pocos segundos. Cada 10 bloques generados = 1 moneda. ¡Mayor velocidad → más monedas!',
    total_coins: 'Total Monedas', total_spawned_stat: 'Total Generados',
    coins_minute: 'Monedas / Minuto', coins_hour: 'Monedas / Hora',
    progress_to: 'Progreso a 1000 monedas',
    farming: '🟢 Cultivando...', not_active: '⚫ Granja inactiva',
  },
    stats: {
    title: '📊 Estadísticas', total_spawned: 'Total Generados',
    total_coins: 'Total Monedas', playtime: 'Tiempo Jugado',
    elements_discovered: 'Elementos Descubiertos', creatures_seen: 'Criaturas Vistas',
    subtitle: '¡Tus estadísticas en vivo!',
    spawn_per_min: 'Generación/Min', coins_per_min: 'Monedas/Min',
    elements_tried: 'Elementos Probados', canvas_cleared: 'Lienzo Limpiado',
    items_bought: 'Artículos Comprados', fps: 'FPS',
    auto_farm_label: 'Auto Farm', auto_farm_on: 'ON', auto_farm_off: 'OFF',
    premium_label: 'Premium', premium_super: '💎 Super',
    premium_active: '👑 Activo', premium_none: '❌ Ninguno',
    active_element: 'Elemento Activo',
    footer_tip: '💡 ¡Sigue jugando para desbloquear logros y recolectar más monedas!',
  },
  seasonsList: {
    spring: { name: 'Primavera', description: '¡Lluvia ligera y las plantas florecen!' },
    summer: { name: 'Verano',    description: '¡Abrasador! ¡El fuego se propaga más rápido, el agua se evapora!' },
    autumn: { name: 'Otoño',     description: '¡Las hojas caen del cielo con el viento!' },
    winter: { name: 'Invierno',  description: '¡Cae nieve abundante, el agua se congela!' },
  },
    tutorial: {
    page_welcome: '👋 ¡Bienvenido!',
    page_howto: '🖱️ Cómo Jugar',
    page_creatures: '🐾 Criaturas Vivas',
    desc_intro: '¡Juego de simulación de partículas físicas! 40+ elementos, Criaturas Vivas, Tienda, Estaciones y Premium!',
    desc_creatures: '¡Elementos vivos que se mueven solos!',
    howto_click: 'Clic / Tocar y Arrastrar',
    howto_click_desc: '¡Mantén pulsado el lienzo y arrastra para dibujar!',
    howto_element: 'Elige Elemento',
    howto_element_desc: 'Toca el botón de elemento abajo (móvil) o panel izquierdo',
    howto_brush: 'Tamaño de Pincel',
    howto_brush_desc: 'Elige 1, 3, 5 u 8 para diferentes pinceles',
    howto_pause: 'Pausa / Reproducir',
    howto_pause_desc: 'Detén/reanuda la simulación en cualquier momento',
    howto_settings: 'Ajustes',
    howto_settings_desc: 'Cambia el tema de color y estación en Ajustes',
    creature_ant: '🐜 Hormiga', creature_ant_desc: 'Camina izq-der, muere en fuego',
    creature_fish: '🐟 Pez', creature_fish_desc: 'Nada dentro del agua',
    creature_bird: '🐦 Pájaro', creature_bird_desc: 'Vuela libremente hacia arriba',
    creature_worm: '🪱 Gusano', creature_worm_desc: 'Cava en arena y tierra',
    creature_frog: '🐸 Rana', creature_frog_desc: 'Salta, ama el agua',
    creature_crab: '🦀 Cangrejo', creature_crab_desc: 'Se mueve de lado en arena',
    creature_bee: '🐝 Abeja', creature_bee_desc: '¡Vuela libre, hace miel!',
    creature_mushroom: '🍄 Hongo', creature_mushroom_desc: 'Crece en tierra húmeda',
    start_playing: '🎮 ¡Jugar!',
    premium_element_locked: '¡Elemento premium! Compra en Tienda primero.',
    open_shop: 'Abrir Tienda',
    tips: 'Consejos',
  },
    admin: {
    title: 'Panel Admin', access_denied: 'Acceso Denegado',
    give_coins: 'Dar Monedas', unlock_all: 'Desbloquear Todo', reset_all: 'Reiniciar Todo',
    god_mode_active: '🔐 Modo Dios Activo',
    manage_points: '💰 Gestionar Puntos', current_points: 'PUNTOS ACTUALES',
    quick_add: 'AGREGAR RÁPIDO:', total_spawned: '🎯 Total Creados',
    premium_and_items: '👑 Premium y Artículos', premium_status: 'ESTADO PREMIUM',
    items_purchased: 'ARTÍCULOS COMPRADOS', game_control: '🎮 Control del Juego',
    pick_element_direct: '⚗️ Elegir Elemento Directo', cheat_codes: '🎯 Códigos Trampa',
    cheats_warning: '⚠️ ¡Estas trampas son solo para pruebas!',
    log: '📋 Registro', admin_mode: '⚡ Modo Admin',
  
    edit: '✏️ Editar', reset_points: '🗑️ Reiniciar Puntos a 0',
    active: '✅ Activo', inactive: '❌ Inactivo',
    activate: '✅ Activar', revoke: '❌ Revocar',
    unlock_all_btn: '🔓 Desbloquear Todo', items_count: 'artículos',
    set_points: '💰 Definir Puntos', set_total_spawned: '🎯 Definir Total Creados',
    close: 'Cerrar',
    log_admin_active: '🔐 ¡Panel Admin Activo!',
    log_points_reset: '💰 Puntos reiniciados a 0',
    log_premium_on: '👑 Premium activado',
    log_premium_off: '👑 Premium revocado',
    log_unlock_all: '🔓 ¡Todos los artículos desbloqueados!',
    log_spawned_set: '🎯 Creados definidos a',
  },
  achievementsList: {
    first_block: { title: 'Primer Paso', desc: '¡Crea el primer bloque!' },
    hundred: { title: '¡Cien!', desc: 'Crea 100 bloques' },
    thousand: { title: '¡Mil!', desc: 'Crea 1.000 bloques' },
    tenk: { title: '¡Diez Mil!', desc: 'Crea 10.000 bloques' },
    hundredk: { title: '¡Cien Mil!', desc: '¡Crea 100.000 bloques!' },
    millionaire: { title: '¡Millonario de Bloques!', desc: '¡Crea 1 millón de bloques!' },
    rich: { title: 'Adinerado', desc: 'Colecciona 1.000 puntos' },
    super_rich: { title: '¡Sultán!', desc: 'Colecciona 10.000 puntos' },
    mega_rich: { title: '¡Magnate!', desc: 'Colecciona 100.000 puntos' },
    premium: { title: 'Realeza', desc: '¡Compra Premium!' },
    superpremium: { title: '¡SuperPremium!', desc: '¡Compra SuperPremium!' },
    explorer: { title: 'Explorador', desc: 'Prueba 10 elementos diferentes' },
    collector: { title: 'Coleccionista', desc: 'Prueba 25 elementos diferentes' },
    master: { title: 'Maestro de Elementos', desc: 'Prueba 50 elementos diferentes' },
    shopper: { title: 'Compulsivo', desc: 'Compra 5 artículos en Tienda' },
    big_shopper: { title: 'Gran Comprador', desc: 'Compra 20 artículos en Tienda' },
    cleaner: { title: 'Limpiador', desc: 'Limpia lienzo 5x' },
    destructive: { title: '¡Destructivo!', desc: 'Limpia lienzo 20x' },
    speed_demon: { title: 'Demonio Veloz', desc: 'Usa velocidad 5x o más' },
    ultra_speed: { title: 'Ultra Velocidad', desc: 'Usa velocidad 10x o más' },
    farmer: { title: 'Granjero Auto', desc: 'Activa Auto Farm' },
    seasonal: { title: 'Cambia-Estaciones', desc: 'Cambia estaciones 4x' },
    veteran: { title: 'Veterano', desc: 'Juega 30 minutos' },
    legend: { title: '¡Leyenda!', desc: 'Juega 2 horas' },
    secret_admin: { title: '???', desc: 'Encuentra el panel oculto' },
  },
};

// ============================================
// 🇨🇳 中文 (Chinese - Simplified)
// ============================================
const zh: Translation = {
  welcome: {
    title: '沙盒世界',
    greeting: '👋 欢迎！',
    description: '物理粒子模拟游戏！40多种元素、活体生物、商店、季节和高级内容！',
    feature_physics: '物理沙盒',
    feature_physics_desc: '实时物理模拟',
    feature_creatures: '活体生物',
    feature_creatures_desc: '蚂蚁、鱼、鸟、青蛙...',
    feature_seasons: '季节系统',
    feature_seasons_desc: '春、夏、秋、冬',
    feature_coins: '10个方块 = 1金币',
    feature_coins_desc: '收集并购物！',
    next: '下一个 →',
    skip: '跳过',
    start: '开始游戏！',
  },
  common: {
    close: '关闭', save: '保存', cancel: '取消', confirm: '确认',
    yes: '是', no: '否', ok: '好', back: '返回', next: '下一个',
    loading: '加载中...', error: '错误', success: '成功',
    buy: '购买', sell: '出售', locked: '已锁定', unlocked: '已解锁',
    coming_soon: '即将推出', free: '免费', premium: '高级',
  },
  game: {
    spawned: '已生成', points: '积分', brush: '画笔', speed: '速度',
    pause: '暂停', play: '播放', clear: '清空', reset: '重置',
    tap_to_change: '点击切换', auto_bot: '自动机器人',
  },
  categories: {
    basic: '基础', earth: '地球', weather: '天气', special: '特殊',
    experimental: '实验', life: '生命', shop: '商店', auto: '自动',
  },
  seasons: {
    title: '季节', spring: '春天', summer: '夏天', autumn: '秋天',
    winter: '冬天', next_in: '下一个季节',
  },
    shop: {
    title: '🛍️ 商店', title_full: 'SandBox 商店', your_coins: '你的金币', not_enough: '金币不足！',
    owned: '已拥有', purchase: '购买', purchased: '已购买！',
    category_creatures: '生物', category_elements: '元素',
    category_powerups: '强化', category_premium: '高级 👑',
    items_count: '个物品', search_placeholder: '🔍 搜索物品...',
    no_items: '😕 没有找到物品',
    consumable: '消耗品', badge_owned: '✅ 已拥有',
    super_active: '超级高级已激活 — 全部功能解锁！',
    premium_subtitle: '20+ 独家特权 + 全部元素解锁！',
    super_premium_subtitle: '25+ 特权 • 巨型地图 • 10倍永久积分！',
    new_badge: '新',
    welcome_premium: '👑 欢迎来到高级！+200 奖励积分！',
    welcome_super_premium: '💎 欢迎来到超级高级！+5000 奖励积分！🚀',
    already_premium: '已是高级会员！👑',
    already_super_premium: '已是超级高级会员！💎',
  },
  settings: {
    title: '⚙️ 设置', language: '语言',
    language_desc: '选择游戏语言',
    sound: '声音', sound_on: '开启', sound_off: '关闭', volume: '音量',
    theme: '主题', map_size: '地图大小', fps: '帧率', show_fps: '显示帧率',
    notifications: '通知', install_app: '安装应用',
    install_desc: '在设备上安装为应用',
    about: '关于', version: '版本', credits: '鸣谢',
    reset_progress: '重置进度', reset_warning: '确定吗？所有进度都将丢失！',
  
    tab_appearance: '🎨 外观', tab_season: '🌸 季节', tab_game: '⚙️ 游戏',
    tab_map: '🗺️ 地图', tab_language: '🌐 语言',
    color_theme: '🎨 颜色主题', preview: '预览',
    auto_season: '自动季节', auto_season_desc: '季节自动变化',
    current_season: '当前季节', pick_season_manual: '手动选择季节',
    season_speed: '⚡ 季节速度',
    speed_slow: '慢', speed_normal: '正常', speed_fast: '快', speed_super: '超级',
    sound_toggle_desc: '开启/关闭音效',
    test_sound: '测试音效',
    show_fps_desc: '在屏幕上查看游戏性能',
    particle_glow: '✨ 粒子发光', particle_glow_desc: '粒子光效（需要GPU）',
    game_info: '💡 游戏信息',
    game_info_text: 'SandBox World v3.0 — 40多种元素、活体生物、季节、商店和高级系统！',
    keyboard_shortcuts: '键盘快捷键',
    shortcut_play_pause: '播放 / 暂停', shortcut_clear: '清空画布', shortcut_shop: '打开商店',
    map_size_title: '🗺️ 地图大小',
    map_size_desc: '在商店购买地图大小来解锁。你可以随时切换回较小的尺寸！',
    map_normal: '正常', map_normal_desc: '默认大小 — 在所有手机上轻便快速',
    map_large: '大 (1.5倍)', map_large_desc: '需要商店的"放大地图"物品 🛍️',
    map_super: '超大 (2倍)', map_super_desc: '需要商店的"超大地图"物品 🛍️',
    map_superpremium: '超级高级 (5倍)', map_superpremium_desc: '巨型地图，国家大小！需要超级高级 💎',
    badge_active: '激活', buy_first: '先购买',
    premium_info: '👑 高级', premium_info_desc: '解锁大地图和超大地图。在商店→特殊购买',
    super_premium_info_desc: '解锁超级高级巨型地图。独家！',
    save_and_close: '✅ 保存并关闭',
    auto_detect_info: '自动检测：首次打开游戏时，语言会自动跟随你的手机/浏览器。',
  },
    achievements: {
    title: '🏆 成就', unlocked: '已解锁', locked: '已锁定',
    progress: '进度', new_achievement: '🏆 新成就！', completion: '完成',
    modal_title: '成就', progress_status: '已解锁 • {progress}% 完成',
    tab_unlocked: '✅ 已解锁', tab_locked: '🔒 已锁定',
    done_badge: '✅ 完成',
    empty_title: '还没有解锁任何成就！',
    empty_subtitle: '先玩玩看吧...',
    secret_locked: '秘密... 继续游玩来解锁！',
  },
    autofarm: {
    title: '自动农场', enable: '启用', disable: '禁用',
    speed: '速度', target: '目标', coins_per_min: '金币/分钟',
    status_active: '激活', status_paused: '暂停',
    subtitle: '自动生成并收集金币！',
    status_on: '🟢 自动农场已开启', status_off: '⚫ 自动农场已关闭',
    btn_start: '▶ 开始', btn_stop: '⏹ 停止',
    tab_settings: '⚙️ 设置', tab_stats: '📊 统计',
    pick_element: '🎯 选择要生成的元素',
    spawn_speed: '⚡ 生成速度',
    how_it_works: '自动农场工作原理',
    how_it_works_desc: '自动农场每几秒在画布上自动生成元素。每生成10个方块 = 1金币。速度越快 → 金币越多！',
    total_coins: '总金币', total_spawned_stat: '总生成',
    coins_minute: '金币/分钟', coins_hour: '金币/小时',
    progress_to: '进度到1000金币',
    farming: '🟢 农场运行中...', not_active: '⚫ 农场未激活',
  },
    stats: {
    title: '📊 游戏统计', total_spawned: '总生成',
    total_coins: '总金币', playtime: '游戏时间',
    elements_discovered: '已发现元素', creatures_seen: '已见生物',
    subtitle: '你的实时统计！',
    spawn_per_min: '生成/分钟', coins_per_min: '金币/分钟',
    elements_tried: '尝试的元素', canvas_cleared: '画布已清空',
    items_bought: '已购物品', fps: '帧率',
    auto_farm_label: '自动农场', auto_farm_on: '开', auto_farm_off: '关',
    premium_label: '高级', premium_super: '💎 超级',
    premium_active: '👑 激活', premium_none: '❌ 无',
    active_element: '激活元素',
    footer_tip: '💡 继续玩以解锁成就并收集更多金币！',
  },
  seasonsList: {
    spring: { name: '春天', description: '细雨绵绵，植物茂盛生长！' },
    summer: { name: '夏天', description: '炎热！火势蔓延更快，水会蒸发！' },
    autumn: { name: '秋天', description: '树叶随风从天而降！' },
    winter: { name: '冬天', description: '大雪纷飞，水会结冰！' },
  },
    tutorial: {
    page_welcome: '👋 欢迎！',
    page_howto: '🖱️ 如何玩',
    page_creatures: '🐾 活体生物',
    desc_intro: '物理粒子模拟游戏！40多种元素、活体生物、商店、季节和高级内容！',
    desc_creatures: '会自行移动的活元素！',
    howto_click: '点击/触摸并拖动',
    howto_click_desc: '在画布上按住然后拖动来绘画！',
    howto_element: '选择元素',
    howto_element_desc: '点击下方元素按钮（手机）或左侧面板',
    howto_brush: '画笔大小',
    howto_brush_desc: '选择1、3、5或8不同的画笔',
    howto_pause: '暂停/播放',
    howto_pause_desc: '随时停止/继续模拟',
    howto_settings: '设置',
    howto_settings_desc: '在设置中更改颜色主题和季节',
    creature_ant: '🐜 蚂蚁', creature_ant_desc: '左右移动，遇火死亡',
    creature_fish: '🐟 鱼', creature_fish_desc: '在水中游泳',
    creature_bird: '🐦 鸟', creature_bird_desc: '自由向上飞翔',
    creature_worm: '🪱 蠕虫', creature_worm_desc: '在沙土中挖洞',
    creature_frog: '🐸 青蛙', creature_frog_desc: '跳跃，喜欢水',
    creature_crab: '🦀 螃蟹', creature_crab_desc: '在沙上侧身移动',
    creature_bee: '🐝 蜜蜂', creature_bee_desc: '自由飞翔，制造蜂蜜！',
    creature_mushroom: '🍄 蘑菇', creature_mushroom_desc: '在潮湿土壤上生长',
    start_playing: '🎮 开始！',
    premium_element_locked: '高级元素！先在商店购买。',
    open_shop: '打开商店',
    tips: '提示',
  },
    admin: {
    title: '管理面板', access_denied: '访问被拒绝',
    give_coins: '给予金币', unlock_all: '解锁全部', reset_all: '重置全部',
    god_mode_active: '🔐 神模式激活',
    manage_points: '💰 管理积分', current_points: '当前积分',
    quick_add: '快速添加：', total_spawned: '🎯 总生成数',
    premium_and_items: '👑 高级与物品', premium_status: '高级状态',
    items_purchased: '已购物品', game_control: '🎮 游戏控制',
    pick_element_direct: '⚗️ 直接选择元素', cheat_codes: '🎯 作弊码',
    cheats_warning: '⚠️ 这些作弊码仅用于测试！',
    log: '📋 日志', admin_mode: '⚡ 管理员模式',
  
    edit: '✏️ 编辑', reset_points: '🗑️ 重置积分为0',
    active: '✅ 激活', inactive: '❌ 未激活',
    activate: '✅ 激活', revoke: '❌ 撤销',
    unlock_all_btn: '🔓 解锁全部', items_count: '个物品',
    set_points: '💰 设置积分', set_total_spawned: '🎯 设置总生成数',
    close: '关闭',
    log_admin_active: '🔐 管理面板已激活！',
    log_points_reset: '💰 积分已重置为0',
    log_premium_on: '👑 高级已激活',
    log_premium_off: '👑 高级已撤销',
    log_unlock_all: '🔓 所有物品已解锁！',
    log_spawned_set: '🎯 生成数设置为',
  },
  achievementsList: {
    first_block: { title: '第一步', desc: '生成第一个方块！' },
    hundred: { title: '一百！', desc: '生成100个方块' },
    thousand: { title: '一千！', desc: '生成1,000个方块' },
    tenk: { title: '一万！', desc: '生成10,000个方块' },
    hundredk: { title: '十万！', desc: '生成100,000个方块！' },
    millionaire: { title: '方块百万富翁！', desc: '生成100万个方块！' },
    rich: { title: '富有', desc: '收集1,000积分' },
    super_rich: { title: '苏丹！', desc: '收集10,000积分' },
    mega_rich: { title: '大亨！', desc: '收集100,000积分' },
    premium: { title: '皇室', desc: '购买高级！' },
    superpremium: { title: '超级高级！', desc: '购买超级高级！' },
    explorer: { title: '探险家', desc: '尝试10种不同元素' },
    collector: { title: '收藏家', desc: '尝试25种不同元素' },
    master: { title: '元素大师', desc: '尝试50种不同元素' },
    shopper: { title: '购物狂', desc: '在商店购买5件物品' },
    big_shopper: { title: '大买家', desc: '在商店购买20件物品' },
    cleaner: { title: '清洁工', desc: '清空画布5次' },
    destructive: { title: '破坏者！', desc: '清空画布20次' },
    speed_demon: { title: '速度恶魔', desc: '使用5倍或更多速度' },
    ultra_speed: { title: '超速', desc: '使用10倍或更多速度' },
    farmer: { title: '自动农夫', desc: '激活自动农场' },
    seasonal: { title: '季节切换者', desc: '更换季节4次' },
    veteran: { title: '老兵', desc: '游玩30分钟' },
    legend: { title: '传奇！', desc: '游玩2小时' },
    secret_admin: { title: '???', desc: '找到隐藏面板' },
  },
};

// ============================================
// 🇯🇵 日本語 (Japanese)
// ============================================
const ja: Translation = {
  welcome: {
    title: 'サンドボックスワールド',
    greeting: '👋 ようこそ！',
    description: '物理粒子シミュレーションゲーム！40種類以上の要素、生き物、ショップ、季節、プレミアム！',
    feature_physics: '物理サンドボックス',
    feature_physics_desc: 'リアルタイム物理シミュレーション',
    feature_creatures: '生き物',
    feature_creatures_desc: 'アリ、魚、鳥、カエル...',
    feature_seasons: '季節システム',
    feature_seasons_desc: '春、夏、秋、冬',
    feature_coins: '10ブロック = 1コイン',
    feature_coins_desc: '集めて買い物！',
    next: '次へ →',
    skip: 'スキップ',
    start: 'プレイ開始！',
  },
  common: {
    close: '閉じる', save: '保存', cancel: 'キャンセル', confirm: '確認',
    yes: 'はい', no: 'いいえ', ok: 'OK', back: '戻る', next: '次へ',
    loading: '読み込み中...', error: 'エラー', success: '成功',
    buy: '購入', sell: '売る', locked: 'ロック', unlocked: 'アンロック',
    coming_soon: '近日公開', free: '無料', premium: 'プレミアム',
  },
  game: {
    spawned: 'スポーン', points: 'ポイント', brush: 'ブラシ', speed: '速度',
    pause: '一時停止', play: '再生', clear: 'クリア', reset: 'リセット',
    tap_to_change: 'タップで変更', auto_bot: 'オートボット',
  },
  categories: {
    basic: '基本', earth: '地球', weather: '天気', special: '特殊',
    experimental: '実験', life: '生命', shop: 'ショップ', auto: '自動',
  },
  seasons: {
    title: '季節', spring: '春', summer: '夏', autumn: '秋',
    winter: '冬', next_in: '次の季節',
  },
    shop: {
    title: '🛍️ ショップ', title_full: 'SandBox ショップ', your_coins: 'コイン', not_enough: 'コイン不足！',
    owned: '所有済み', purchase: '購入', purchased: '購入済み！',
    category_creatures: '生き物', category_elements: '要素',
    category_powerups: 'パワーアップ', category_premium: 'プレミアム 👑',
    items_count: 'アイテム', search_placeholder: '🔍 アイテム検索...',
    no_items: '😕 アイテムが見つかりません',
    consumable: '消費型', badge_owned: '✅ 所有済み',
    super_active: 'スーパープレミアム有効 — 全機能アンロック！',
    premium_subtitle: '20+ 限定特典 + 全要素アンロック！',
    super_premium_subtitle: '25+ 特典 • 巨大マップ • 10倍永久ポイント！',
    new_badge: '新',
    welcome_premium: '👑 プレミアムへようこそ！+200ボーナスポイント！',
    welcome_super_premium: '💎 スーパープレミアムへようこそ！+5000ボーナスポイント！🚀',
    already_premium: '既にプレミアム！👑',
    already_super_premium: '既にスーパープレミアム！💎',
  },
  settings: {
    title: '⚙️ 設定', language: '言語',
    language_desc: 'ゲームの言語を選択',
    sound: 'サウンド', sound_on: 'オン', sound_off: 'オフ', volume: '音量',
    theme: 'テーマ', map_size: 'マップサイズ', fps: 'FPS', show_fps: 'FPSを表示',
    notifications: '通知', install_app: 'アプリをインストール',
    install_desc: 'デバイスにアプリとしてインストール',
    about: '情報', version: 'バージョン', credits: 'クレジット',
    reset_progress: '進行状況をリセット', reset_warning: 'よろしいですか？全ての進行状況が失われます！',
  
    tab_appearance: '🎨 外観', tab_season: '🌸 季節', tab_game: '⚙️ ゲーム',
    tab_map: '🗺️ マップ', tab_language: '🌐 言語',
    color_theme: '🎨 カラーテーマ', preview: 'プレビュー',
    auto_season: '自動季節', auto_season_desc: '季節が自動的に変わる',
    current_season: '現在の季節', pick_season_manual: '季節を手動選択',
    season_speed: '⚡ 季節の速度',
    speed_slow: '遅い', speed_normal: '普通', speed_fast: '速い', speed_super: '超速',
    sound_toggle_desc: 'サウンド効果のオン/オフ',
    test_sound: 'サウンドテスト',
    show_fps_desc: '画面でゲームパフォーマンスを確認',
    particle_glow: '✨ パーティクルグロー', particle_glow_desc: 'パーティクル光効果（GPU必要）',
    game_info: '💡 ゲーム情報',
    game_info_text: 'SandBox World v3.0 — 40種類以上の要素、生き物、季節、ショップ、プレミアムシステム！',
    keyboard_shortcuts: 'キーボードショートカット',
    shortcut_play_pause: '再生 / 一時停止', shortcut_clear: 'キャンバスクリア', shortcut_shop: 'ショップを開く',
    map_size_title: '🗺️ マップサイズ',
    map_size_desc: 'マップサイズをショップで購入してアンロック。いつでも小さいサイズに戻せます！',
    map_normal: '通常', map_normal_desc: 'デフォルトサイズ — 全ての携帯で軽快',
    map_large: '大 (1.5倍)', map_large_desc: 'ショップの「マップ拡大」アイテムが必要 🛍️',
    map_super: '超大 (2倍)', map_super_desc: 'ショップの「超大マップ」アイテムが必要 🛍️',
    map_superpremium: 'スーパープレミアム (5倍)', map_superpremium_desc: 'メガ巨大、国土サイズ！スーパープレミアム必要 💎',
    badge_active: '有効', buy_first: '先に購入',
    premium_info: '👑 プレミアム', premium_info_desc: '大マップと超大マップをアンロック。ショップ→スペシャルで購入',
    super_premium_info_desc: 'スーパープレミアム巨大マップをアンロック。独占！',
    save_and_close: '✅ 保存して閉じる',
    auto_detect_info: '自動検出：ゲーム初回起動時、言語が自動的に携帯/ブラウザに従います。',
  },
    achievements: {
    title: '🏆 実績', unlocked: 'アンロック', locked: 'ロック',
    progress: '進行状況', new_achievement: '🏆 新しい実績！', completion: '完了',
    modal_title: '実績', progress_status: 'アンロック • {progress}% 完了',
    tab_unlocked: '✅ アンロック', tab_locked: '🔒 ロック',
    done_badge: '✅ 完了',
    empty_title: 'まだ実績がアンロックされていません！',
    empty_subtitle: 'まずプレイしてみよう...',
    secret_locked: '秘密... プレイを続けてアンロック！',
  },
    autofarm: {
    title: 'オートファーム', enable: '有効化', disable: '無効化',
    speed: '速度', target: 'ターゲット', coins_per_min: 'コイン/分',
    status_active: 'アクティブ', status_paused: '一時停止',
    subtitle: '自動スポーン＆コイン収集！',
    status_on: '🟢 オートファーム ON', status_off: '⚫ オートファーム OFF',
    btn_start: '▶ 開始', btn_stop: '⏹ 停止',
    tab_settings: '⚙️ 設定', tab_stats: '📊 統計',
    pick_element: '🎯 スポーンする要素を選択',
    spawn_speed: '⚡ スポーン速度',
    how_it_works: 'オートファームの仕組み',
    how_it_works_desc: 'オートファームは数秒ごとにキャンバスに要素を自動スポーンします。10ブロックスポーン = 1コイン。速度が速いほど → コインが多くなります！',
    total_coins: '総コイン', total_spawned_stat: '総スポーン',
    coins_minute: 'コイン/分', coins_hour: 'コイン/時',
    progress_to: '1000コインまでの進捗',
    farming: '🟢 ファーム中...', not_active: '⚫ ファーム未アクティブ',
  },
    stats: {
    title: '📊 ゲーム統計', total_spawned: '総スポーン',
    total_coins: '総コイン', playtime: 'プレイ時間',
    elements_discovered: '発見した要素', creatures_seen: '見た生き物',
    subtitle: 'あなたのリアルタイム統計！',
    spawn_per_min: 'スポーン/分', coins_per_min: 'コイン/分',
    elements_tried: '試した要素', canvas_cleared: 'キャンバスクリア',
    items_bought: '購入アイテム', fps: 'FPS',
    auto_farm_label: 'オートファーム', auto_farm_on: 'ON', auto_farm_off: 'OFF',
    premium_label: 'プレミアム', premium_super: '💎 スーパー',
    premium_active: '👑 有効', premium_none: '❌ なし',
    active_element: 'アクティブ要素',
    footer_tip: '💡 プレイを続けて実績を解除し、より多くのコインを集めよう！',
  },
  seasonsList: {
    spring: { name: '春', description: '小雨が降り、植物が豊かに育つ！' },
    summer: { name: '夏', description: '灼熱！火が早く広がり、水が蒸発する！' },
    autumn: { name: '秋', description: '葉が風と共に空から落ちる！' },
    winter: { name: '冬', description: '大雪が降り、水が凍る！' },
  },
    tutorial: {
    page_welcome: '👋 ようこそ！',
    page_howto: '🖱️ 遊び方',
    page_creatures: '🐾 生き物',
    desc_intro: '物理粒子シミュレーションゲーム！40種類以上の要素、生き物、ショップ、季節、プレミアム！',
    desc_creatures: '自分で動く生きた要素！',
    howto_click: 'クリック/タッチ＆ドラッグ',
    howto_click_desc: 'キャンバスを長押ししてドラッグして描く！',
    howto_element: '要素を選択',
    howto_element_desc: '下の要素ボタン（モバイル）または左パネル',
    howto_brush: 'ブラシサイズ',
    howto_brush_desc: '1、3、5、8から異なるブラシを選択',
    howto_pause: '一時停止/再生',
    howto_pause_desc: 'シミュレーションをいつでも停止/再開',
    howto_settings: '設定',
    howto_settings_desc: '設定でカラーテーマと季節を変更',
    creature_ant: '🐜 アリ', creature_ant_desc: '左右に動き、火で死ぬ',
    creature_fish: '🐟 魚', creature_fish_desc: '水中を泳ぐ',
    creature_bird: '🐦 鳥', creature_bird_desc: '上向きに自由に飛ぶ',
    creature_worm: '🪱 ミミズ', creature_worm_desc: '砂と土を掘る',
    creature_frog: '🐸 カエル', creature_frog_desc: '飛び跳ね、水が好き',
    creature_crab: '🦀 カニ', creature_crab_desc: '砂の上を横向きに動く',
    creature_bee: '🐝 ハチ', creature_bee_desc: '自由に飛び、蜂蜜を作る！',
    creature_mushroom: '🍄 キノコ', creature_mushroom_desc: '湿った土に育つ',
    start_playing: '🎮 プレイ！',
    premium_element_locked: 'プレミアム要素！ショップで購入してください。',
    open_shop: 'ショップを開く',
    tips: 'ヒント',
  },
    admin: {
    title: '管理パネル', access_denied: 'アクセス拒否',
    give_coins: 'コインを与える', unlock_all: '全てアンロック', reset_all: '全てリセット',
    god_mode_active: '🔐 ゴッドモード有効',
    manage_points: '💰 ポイント管理', current_points: '現在のポイント',
    quick_add: 'クイック追加：', total_spawned: '🎯 総スポーン数',
    premium_and_items: '👑 プレミアムとアイテム', premium_status: 'プレミアム状態',
    items_purchased: '購入済みアイテム', game_control: '🎮 ゲームコントロール',
    pick_element_direct: '⚗️ 要素を直接選択', cheat_codes: '🎯 チートコード',
    cheats_warning: '⚠️ これらのチートはテスト専用です！',
    log: '📋 ログ', admin_mode: '⚡ 管理者モード',
  
    edit: '✏️ 編集', reset_points: '🗑️ ポイントを0にリセット',
    active: '✅ 有効', inactive: '❌ 無効',
    activate: '✅ 有効化', revoke: '❌ 取り消し',
    unlock_all_btn: '🔓 全てアンロック', items_count: 'アイテム',
    set_points: '💰 ポイント設定', set_total_spawned: '🎯 総スポーン数設定',
    close: '閉じる',
    log_admin_active: '🔐 管理パネル有効！',
    log_points_reset: '💰 ポイントを0にリセット',
    log_premium_on: '👑 プレミアム有効化',
    log_premium_off: '👑 プレミアム取り消し',
    log_unlock_all: '🔓 全アイテムアンロック！',
    log_spawned_set: '🎯 スポーン数を',
  },
  achievementsList: {
    first_block: { title: '最初の一歩', desc: '最初のブロックをスポーン！' },
    hundred: { title: '100個！', desc: '100個のブロックをスポーン' },
    thousand: { title: '1000個！', desc: '1,000個のブロックをスポーン' },
    tenk: { title: '1万個！', desc: '10,000個のブロックをスポーン' },
    hundredk: { title: '10万個！', desc: '100,000個のブロックをスポーン！' },
    millionaire: { title: 'ブロック百万長者！', desc: '100万個のブロックをスポーン！' },
    rich: { title: 'お金持ち', desc: '1,000ポイント集める' },
    super_rich: { title: 'スルタン！', desc: '10,000ポイント集める' },
    mega_rich: { title: '大富豪！', desc: '100,000ポイント集める' },
    premium: { title: '王族', desc: 'プレミアム購入！' },
    superpremium: { title: 'スーパープレミアム！', desc: 'スーパープレミアム購入！' },
    explorer: { title: '探検家', desc: '10種類の異なる要素を試す' },
    collector: { title: 'コレクター', desc: '25種類の異なる要素を試す' },
    master: { title: '要素マスター', desc: '50種類の異なる要素を試す' },
    shopper: { title: '買い物好き', desc: 'ショップで5アイテム購入' },
    big_shopper: { title: '大金持ち', desc: 'ショップで20アイテム購入' },
    cleaner: { title: '清掃者', desc: 'キャンバスを5回クリア' },
    destructive: { title: '破壊的！', desc: 'キャンバスを20回クリア' },
    speed_demon: { title: 'スピード狂', desc: '5倍速以上を使用' },
    ultra_speed: { title: 'ウルトラスピード', desc: '10倍速以上を使用' },
    farmer: { title: 'オートファーマー', desc: 'オートファーム有効化' },
    seasonal: { title: '季節チェンジャー', desc: '季節を4回変更' },
    veteran: { title: 'ベテラン', desc: '30分プレイ' },
    legend: { title: '伝説！', desc: '2時間プレイ' },
    secret_admin: { title: '???', desc: '隠しパネルを見つける' },
  },
};

// ============================================
// 🇸🇦 العربية (Arabic - RTL)
// ============================================
const ar: Translation = {
  welcome: {
    title: 'عالم الصندوق الرملي',
    greeting: '👋 أهلاً بك!',
    description: 'لعبة محاكاة فيزياء الجسيمات! 40+ عنصر، كائنات حية، متجر، فصول، وبريميوم!',
    feature_physics: 'صندوق الفيزياء',
    feature_physics_desc: 'محاكاة فيزيائية في الوقت الفعلي',
    feature_creatures: 'الكائنات الحية',
    feature_creatures_desc: 'نملة، سمكة، طائر، ضفدع...',
    feature_seasons: 'نظام الفصول',
    feature_seasons_desc: 'الربيع، الصيف، الخريف، الشتاء',
    feature_coins: '10 مكعبات = 1 عملة',
    feature_coins_desc: 'اجمع وتسوّق!',
    next: 'التالي ←',
    skip: 'تخطّي',
    start: 'ابدأ اللعب!',
  },
  common: {
    close: 'إغلاق', save: 'حفظ', cancel: 'إلغاء', confirm: 'تأكيد',
    yes: 'نعم', no: 'لا', ok: 'موافق', back: 'رجوع', next: 'التالي',
    loading: 'جارٍ التحميل...', error: 'خطأ', success: 'نجاح',
    buy: 'شراء', sell: 'بيع', locked: 'مقفل', unlocked: 'مفتوح',
    coming_soon: 'قريباً', free: 'مجاني', premium: 'بريميوم',
  },
  game: {
    spawned: 'تم إنشاء', points: 'نقاط', brush: 'فرشاة', speed: 'سرعة',
    pause: 'إيقاف', play: 'تشغيل', clear: 'مسح', reset: 'إعادة',
    tap_to_change: 'انقر للتغيير', auto_bot: 'بوت تلقائي',
  },
  categories: {
    basic: 'أساسي', earth: 'أرض', weather: 'طقس', special: 'خاص',
    experimental: 'تجريبي', life: 'حياة', shop: 'متجر', auto: 'تلقائي',
  },
  seasons: {
    title: 'الفصل', spring: 'الربيع', summer: 'الصيف', autumn: 'الخريف',
    winter: 'الشتاء', next_in: 'التالي خلال',
  },
    shop: {
    title: '🛍️ المتجر', title_full: 'متجر SandBox', your_coins: 'عملاتك', not_enough: 'عملات غير كافية!',
    owned: 'مملوك', purchase: 'شراء', purchased: 'تم الشراء!',
    category_creatures: 'كائنات', category_elements: 'عناصر',
    category_powerups: 'تعزيزات', category_premium: 'بريميوم 👑',
    items_count: 'عنصر', search_placeholder: '🔍 ابحث عن عنصر...',
    no_items: '😕 لم يتم العثور على عناصر',
    consumable: 'قابل للاستهلاك', badge_owned: '✅ مملوك',
    super_active: 'بريميوم خارق نشط — جميع الميزات مفتوحة!',
    premium_subtitle: '20+ ميزة حصرية + جميع العناصر مفتوحة!',
    super_premium_subtitle: '25+ ميزة • خريطة عملاقة • 10x نقاط دائمة!',
    new_badge: 'جديد',
    welcome_premium: '👑 مرحباً بك في البريميوم! +200 نقطة إضافية!',
    welcome_super_premium: '💎 مرحباً بك في البريميوم الخارق! +5000 نقطة! 🚀',
    already_premium: 'بريميوم بالفعل! 👑',
    already_super_premium: 'بريميوم خارق بالفعل! 💎',
  },
  settings: {
    title: '⚙️ الإعدادات', language: 'اللغة',
    language_desc: 'اختر لغة اللعبة',
    sound: 'الصوت', sound_on: 'تشغيل', sound_off: 'إيقاف', volume: 'مستوى الصوت',
    theme: 'السمة', map_size: 'حجم الخريطة', fps: 'الإطارات', show_fps: 'عرض الإطارات',
    notifications: 'الإشعارات', install_app: 'تثبيت التطبيق',
    install_desc: 'ثبّت كتطبيق على جهازك',
    about: 'حول', version: 'الإصدار', credits: 'الفريق',
    reset_progress: 'إعادة التقدم', reset_warning: 'هل أنت متأكد؟ سيتم فقدان كل التقدم!',
  
    tab_appearance: '🎨 المظهر', tab_season: '🌸 الفصل', tab_game: '⚙️ اللعبة',
    tab_map: '🗺️ الخريطة', tab_language: '🌐 اللغة',
    color_theme: '🎨 سمة اللون', preview: 'معاينة',
    auto_season: 'فصل تلقائي', auto_season_desc: 'الفصول تتغير تلقائياً',
    current_season: 'الفصل الحالي', pick_season_manual: 'اختر الفصل يدوياً',
    season_speed: '⚡ سرعة الفصل',
    speed_slow: 'بطيء', speed_normal: 'عادي', speed_fast: 'سريع', speed_super: 'خارق',
    sound_toggle_desc: 'تشغيل/إيقاف المؤثرات الصوتية',
    test_sound: 'اختبار الصوت',
    show_fps_desc: 'شاهد أداء اللعبة على الشاشة',
    particle_glow: '✨ توهج الجسيمات', particle_glow_desc: 'تأثير ضوء الجسيمات (يحتاج GPU)',
    game_info: '💡 معلومات اللعبة',
    game_info_text: 'SandBox World v3.0 — 40+ عنصر، كائنات حية، فصول، متجر، ونظام بريميوم!',
    keyboard_shortcuts: 'اختصارات لوحة المفاتيح',
    shortcut_play_pause: 'تشغيل / إيقاف', shortcut_clear: 'مسح اللوحة', shortcut_shop: 'افتح المتجر',
    map_size_title: '🗺️ حجم الخريطة',
    map_size_desc: 'اشتر أحجام الخريطة من المتجر للفتح. يمكنك العودة لأحجام أصغر في أي وقت!',
    map_normal: 'عادي', map_normal_desc: 'الحجم الافتراضي — خفيف وسريع على جميع الهواتف',
    map_large: 'كبير (1.5x)', map_large_desc: 'يحتاج عنصر "تكبير الخريطة" من المتجر 🛍️',
    map_super: 'ضخم (2x)', map_super_desc: 'يحتاج عنصر "خريطة ضخمة" من المتجر 🛍️',
    map_superpremium: 'بريميوم خارق (5x)', map_superpremium_desc: 'عملاق ضخم بحجم دولة! يحتاج بريميوم خارق 💎',
    badge_active: 'نشط', buy_first: 'اشتر أولاً',
    premium_info: '👑 بريميوم', premium_info_desc: 'افتح الخريطة الكبيرة والضخمة. اشتر من المتجر → خاص',
    super_premium_info_desc: 'افتح خريطة البريميوم الخارق العملاقة. حصري!',
    save_and_close: '✅ احفظ وأغلق',
    auto_detect_info: 'الكشف التلقائي: اللغة تتبع هاتفك/المتصفح تلقائياً عند فتح اللعبة لأول مرة.',
  },
    achievements: {
    title: '🏆 الإنجازات', unlocked: 'مفتوح', locked: 'مقفل',
    progress: 'التقدم', new_achievement: '🏆 إنجاز جديد!', completion: 'مكتمل',
    modal_title: 'الإنجازات', progress_status: 'مفتوح • {progress}% مكتمل',
    tab_unlocked: '✅ مفتوح', tab_locked: '🔒 مقفل',
    done_badge: '✅ تم',
    empty_title: 'لم يتم فتح أي إنجاز بعد!',
    empty_subtitle: 'العب أولاً...',
    secret_locked: 'سرّي... استمر باللعب للفتح!',
  },
    autofarm: {
    title: 'المزرعة التلقائية', enable: 'تفعيل', disable: 'تعطيل',
    speed: 'السرعة', target: 'الهدف', coins_per_min: 'عملة/دقيقة',
    status_active: 'نشط', status_paused: 'متوقف',
    subtitle: 'إنشاء تلقائي وجمع العملات!',
    status_on: '🟢 المزرعة التلقائية نشطة', status_off: '⚫ المزرعة التلقائية متوقفة',
    btn_start: '▶ ابدأ', btn_stop: '⏹ إيقاف',
    tab_settings: '⚙️ الإعدادات', tab_stats: '📊 الإحصائيات',
    pick_element: '🎯 اختر العنصر للإنشاء',
    spawn_speed: '⚡ سرعة الإنشاء',
    how_it_works: 'كيف تعمل المزرعة التلقائية',
    how_it_works_desc: 'المزرعة التلقائية تنشئ عناصر على اللوحة كل بضع ثوانٍ. كل 10 بلوكات منشأة = 1 عملة. كلما زادت السرعة → زادت العملات!',
    total_coins: 'إجمالي العملات', total_spawned_stat: 'إجمالي الإنشاء',
    coins_minute: 'عملة / دقيقة', coins_hour: 'عملة / ساعة',
    progress_to: 'التقدم إلى 1000 عملة',
    farming: '🟢 جاري الزراعة...', not_active: '⚫ المزرعة غير نشطة',
  },
    stats: {
    title: '📊 إحصائيات اللعبة', total_spawned: 'إجمالي الإنشاء',
    total_coins: 'إجمالي العملات', playtime: 'وقت اللعب',
    elements_discovered: 'العناصر المكتشفة', creatures_seen: 'الكائنات المرئية',
    subtitle: 'إحصائياتك المباشرة!',
    spawn_per_min: 'إنشاء/دقيقة', coins_per_min: 'عملات/دقيقة',
    elements_tried: 'العناصر المجربة', canvas_cleared: 'اللوحة الممسوحة',
    items_bought: 'العناصر المشتراة', fps: 'الإطارات',
    auto_farm_label: 'مزرعة تلقائية', auto_farm_on: 'تشغيل', auto_farm_off: 'إيقاف',
    premium_label: 'بريميوم', premium_super: '💎 خارق',
    premium_active: '👑 نشط', premium_none: '❌ لا يوجد',
    active_element: 'العنصر النشط',
    footer_tip: '💡 استمر باللعب لفتح الإنجازات وجمع المزيد من العملات!',
  },
  seasonsList: {
    spring: { name: 'الربيع', description: 'مطر خفيف والنباتات تزدهر!' },
    summer: { name: 'الصيف',  description: 'حرّ! النار تنتشر أسرع، الماء يتبخر!' },
    autumn: { name: 'الخريف', description: 'الأوراق تتساقط من السماء مع الرياح!' },
    winter: { name: 'الشتاء', description: 'الثلج يتساقط بغزارة، الماء يتجمد!' },
  },
    tutorial: {
    page_welcome: '👋 أهلاً بك!',
    page_howto: '🖱️ كيفية اللعب',
    page_creatures: '🐾 الكائنات الحية',
    desc_intro: 'لعبة محاكاة فيزياء الجسيمات! 40+ عنصر، كائنات حية، متجر، فصول، وبريميوم!',
    desc_creatures: 'عناصر حية تتحرك بنفسها!',
    howto_click: 'النقر / اللمس والسحب',
    howto_click_desc: 'اضغط على اللوحة ثم اسحب للرسم!',
    howto_element: 'اختر عنصر',
    howto_element_desc: 'انقر على زر العنصر أدناه (الجوال) أو اللوحة اليسرى',
    howto_brush: 'حجم الفرشاة',
    howto_brush_desc: 'اختر 1 أو 3 أو 5 أو 8 لفرش مختلفة',
    howto_pause: 'إيقاف مؤقت / تشغيل',
    howto_pause_desc: 'أوقف/استأنف المحاكاة في أي وقت',
    howto_settings: 'الإعدادات',
    howto_settings_desc: 'غيّر سمة اللون والفصل في الإعدادات',
    creature_ant: '🐜 نملة', creature_ant_desc: 'تتحرك يميناً ويساراً، تموت بالنار',
    creature_fish: '🐟 سمكة', creature_fish_desc: 'تسبح داخل الماء',
    creature_bird: '🐦 طائر', creature_bird_desc: 'يطير بحرية إلى الأعلى',
    creature_worm: '🪱 دودة', creature_worm_desc: 'تحفر في الرمل والتراب',
    creature_frog: '🐸 ضفدع', creature_frog_desc: 'تقفز، تحب الماء',
    creature_crab: '🦀 سلطعون', creature_crab_desc: 'يتحرك جانبياً على الرمل',
    creature_bee: '🐝 نحلة', creature_bee_desc: 'تطير بحرية، تصنع العسل!',
    creature_mushroom: '🍄 فطر', creature_mushroom_desc: 'ينمو في التربة الرطبة',
    start_playing: '🎮 العب!',
    premium_element_locked: 'عنصر بريميوم! اشتر من المتجر أولاً.',
    open_shop: 'افتح المتجر',
    tips: 'نصائح',
  },
    admin: {
    title: 'لوحة الإدارة', access_denied: 'الوصول مرفوض',
    give_coins: 'إعطاء عملات', unlock_all: 'فتح الكل', reset_all: 'إعادة الكل',
    god_mode_active: '🔐 وضع الإله نشط',
    manage_points: '💰 إدارة النقاط', current_points: 'النقاط الحالية',
    quick_add: 'إضافة سريعة:', total_spawned: '🎯 إجمالي الإنشاء',
    premium_and_items: '👑 بريميوم وعناصر', premium_status: 'حالة البريميوم',
    items_purchased: 'العناصر المشتراة', game_control: '🎮 التحكم بالعبة',
    pick_element_direct: '⚗️ اختر عنصر مباشرة', cheat_codes: '🎯 رموز الغش',
    cheats_warning: '⚠️ هذه الغش للاختبار فقط!',
    log: '📋 السجل', admin_mode: '⚡ وضع الإدارة',
  
    edit: '✏️ تعديل', reset_points: '🗑️ إعادة النقاط إلى 0',
    active: '✅ نشط', inactive: '❌ غير نشط',
    activate: '✅ تفعيل', revoke: '❌ إلغاء',
    unlock_all_btn: '🔓 فتح الكل', items_count: 'عنصر',
    set_points: '💰 تعيين النقاط', set_total_spawned: '🎯 تعيين الإجمالي',
    close: 'إغلاق',
    log_admin_active: '🔐 لوحة الإدارة نشطة!',
    log_points_reset: '💰 تم إعادة النقاط إلى 0',
    log_premium_on: '👑 تم تفعيل البريميوم',
    log_premium_off: '👑 تم إلغاء البريميوم',
    log_unlock_all: '🔓 تم فتح جميع العناصر!',
    log_spawned_set: '🎯 تعيين الإنشاء إلى',
  },
  achievementsList: {
    first_block: { title: 'الخطوة الأولى', desc: 'أنشئ أول بلوك!' },
    hundred: { title: 'مئة!', desc: 'أنشئ 100 بلوك' },
    thousand: { title: 'ألف!', desc: 'أنشئ 1000 بلوك' },
    tenk: { title: 'عشرة آلاف!', desc: 'أنشئ 10000 بلوك' },
    hundredk: { title: 'مئة ألف!', desc: 'أنشئ 100000 بلوك!' },
    millionaire: { title: 'مليونير البلوكات!', desc: 'أنشئ مليون بلوك!' },
    rich: { title: 'ثري', desc: 'اجمع 1000 نقطة' },
    super_rich: { title: 'سلطان!', desc: 'اجمع 10000 نقطة' },
    mega_rich: { title: 'قطب!', desc: 'اجمع 100000 نقطة' },
    premium: { title: 'ملكي', desc: 'اشتر البريميوم!' },
    superpremium: { title: 'بريميوم خارق!', desc: 'اشتر البريميوم الخارق!' },
    explorer: { title: 'مستكشف', desc: 'جرب 10 عناصر مختلفة' },
    collector: { title: 'جامع', desc: 'جرب 25 عنصر مختلف' },
    master: { title: 'سيد العناصر', desc: 'جرب 50 عنصر مختلف' },
    shopper: { title: 'مدمن تسوق', desc: 'اشتر 5 عناصر من المتجر' },
    big_shopper: { title: 'منفق كبير', desc: 'اشتر 20 عنصر من المتجر' },
    cleaner: { title: 'منظف', desc: 'امسح اللوحة 5 مرات' },
    destructive: { title: 'مدمر!', desc: 'امسح اللوحة 20 مرة' },
    speed_demon: { title: 'شيطان السرعة', desc: 'استخدم سرعة 5x أو أكثر' },
    ultra_speed: { title: 'سرعة فائقة', desc: 'استخدم سرعة 10x أو أكثر' },
    farmer: { title: 'مزارع تلقائي', desc: 'فعّل المزرعة التلقائية' },
    seasonal: { title: 'مغير الفصول', desc: 'غيّر الفصول 4 مرات' },
    veteran: { title: 'محنك', desc: 'العب 30 دقيقة' },
    legend: { title: 'أسطورة!', desc: 'العب لمدة ساعتين' },
    secret_admin: { title: '؟؟؟', desc: 'اعثر على اللوحة المخفية' },
  },
};

// Export semua translations
export const TRANSLATIONS: Record<LanguageCode, Translation> = {
  id, en, es, zh, ja, ar,
};

// Helper: dapetin info bahasa dari kode
export function getLanguageInfo(code: LanguageCode): LanguageInfo {
  return LANGUAGES.find(l => l.code === code) || LANGUAGES[0];
}

// 🌐 Language Selector Component
// Dropdown bahasa yang kece, dipake di Settings Modal

import { useState, useRef, useEffect } from 'react';
import { useI18n } from './I18nContext';
import type { LanguageCode } from './translations';

interface LanguageSelectorProps {
  className?: string;
  variant?: 'dropdown' | 'grid';
}

export default function LanguageSelector({
  className = '',
  variant = 'dropdown',
}: LanguageSelectorProps) {
  const { language, setLanguage, availableLanguages, t } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown kalau click di luar
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  const currentLang = availableLanguages.find(l => l.code === language)!;

  const handleSelect = (code: LanguageCode) => {
    setLanguage(code);
    setIsOpen(false);
  };

  // ===== GRID VARIANT (semua bahasa kelihatan) =====
  if (variant === 'grid') {
    return (
      <div className={className}>
        <label
          style={{
            display: 'block',
            fontSize: '14px',
            fontWeight: 600,
            color: '#e5e7eb',
            marginBottom: '8px',
          }}
        >
          🌐 {t.settings.language}
        </label>
        <p
          style={{
            fontSize: '12px',
            color: '#9ca3af',
            marginBottom: '12px',
          }}
        >
          {t.settings.language_desc}
        </p>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 1fr)',
            gap: '8px',
          }}
        >
          {availableLanguages.map(lang => {
            const isActive = lang.code === language;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  border: isActive ? '2px solid #3b82f6' : '2px solid #374151',
                  background: isActive ? '#1e3a8a' : '#1f2937',
                  color: '#fff',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                  fontSize: '14px',
                  textAlign: 'left',
                }}
                onMouseEnter={e => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background = '#374151';
                  }
                }}
                onMouseLeave={e => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background = '#1f2937';
                  }
                }}
              >
                <span style={{ fontSize: '20px' }}>{lang.flag}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {lang.name}
                  </div>
                  <div style={{ fontSize: '10px', color: '#9ca3af' }}>
                    {lang.englishName}
                  </div>
                </div>
                {isActive && (
                  <span style={{ color: '#3b82f6', fontSize: '16px' }}>✓</span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  // ===== DROPDOWN VARIANT (default, compact) =====
  return (
    <div className={className} ref={dropdownRef} style={{ position: 'relative' }}>
      <label
        style={{
          display: 'block',
          fontSize: '14px',
          fontWeight: 600,
          color: '#e5e7eb',
          marginBottom: '6px',
        }}
      >
        🌐 {t.settings.language}
      </label>

      {/* Trigger button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        style={{
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '8px',
          padding: '10px 14px',
          borderRadius: '8px',
          border: '2px solid #374151',
          background: '#1f2937',
          color: '#fff',
          cursor: 'pointer',
          fontSize: '14px',
          fontWeight: 500,
          transition: 'all 0.15s',
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLElement).style.borderColor = '#3b82f6';
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLElement).style.borderColor = '#374151';
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ fontSize: '20px' }}>{currentLang.flag}</span>
          <span>{currentLang.name}</span>
          <span style={{ fontSize: '11px', color: '#9ca3af' }}>
            ({currentLang.englishName})
          </span>
        </span>
        <span
          style={{
            transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
            transition: 'transform 0.2s',
            color: '#9ca3af',
          }}
        >
          ▼
        </span>
      </button>

      {/* Dropdown menu */}
      {isOpen && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 4px)',
            left: 0,
            right: 0,
            background: '#111827',
            border: '2px solid #374151',
            borderRadius: '8px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
            zIndex: 1000,
            maxHeight: '280px',
            overflowY: 'auto',
          }}
        >
          {availableLanguages.map(lang => {
            const isActive = lang.code === language;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px',
                  padding: '12px 14px',
                  border: 'none',
                  background: isActive ? '#1e3a8a' : 'transparent',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: '14px',
                  textAlign: 'left',
                  transition: 'background 0.1s',
                }}
                onMouseEnter={e => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background = '#1f2937';
                  }
                }}
                onMouseLeave={e => {
                  if (!isActive) {
                    (e.currentTarget as HTMLElement).style.background = 'transparent';
                  }
                }}
              >
                <span style={{ fontSize: '22px' }}>{lang.flag}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{lang.name}</div>
                  <div style={{ fontSize: '11px', color: '#9ca3af' }}>
                    {lang.englishName}
                  </div>
                </div>
                {isActive && (
                  <span style={{ color: '#3b82f6', fontSize: '16px' }}>✓</span>
                )}
              </button>
            );
          })}
        </div>
      )}

      <p
        style={{
          fontSize: '11px',
          color: '#9ca3af',
          marginTop: '6px',
        }}
      >
        {t.settings.language_desc}
      </p>
    </div>
  );
}

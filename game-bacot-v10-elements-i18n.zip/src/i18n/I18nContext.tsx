// 🌐 i18n Context untuk SandBox World
// Auto-detect bahasa browser/HP, simpan ke localStorage, support RTL

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  LanguageCode,
  LANGUAGES,
  TRANSLATIONS,
  Translation,
  getLanguageInfo,
} from './translations';

const STORAGE_KEY = 'sandbox-world-language';

interface I18nContextValue {
  language: LanguageCode;
  setLanguage: (code: LanguageCode) => void;
  t: Translation;
  isRTL: boolean;
  availableLanguages: typeof LANGUAGES;
}

const I18nContext = createContext<I18nContextValue | null>(null);

/**
 * Deteksi bahasa otomatis dari browser/OS.
 * Fallback ke 'id' (Indonesia) kalau gak ke-detect.
 */
function detectBrowserLanguage(): LanguageCode {
  // 1. Cek localStorage dulu (user preference)
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved && LANGUAGES.some(l => l.code === saved)) {
      return saved as LanguageCode;
    }
  } catch {
    // localStorage gak available (private mode dll), skip
  }

  // 2. Cek bahasa browser
  if (typeof navigator !== 'undefined') {
    const browserLangs = [
      navigator.language,
      ...(navigator.languages || []),
    ];

    for (const lang of browserLangs) {
      if (!lang) continue;
      const code = lang.toLowerCase().split('-')[0]; // "en-US" → "en"

      // Mapping bahasa browser ke kode kita
      const mapping: Record<string, LanguageCode> = {
        id: 'id',
        in: 'id', // Old Indonesian code
        ms: 'id', // Malay (mirip Indo)
        en: 'en',
        es: 'es',
        zh: 'zh',
        ja: 'ja',
        ar: 'ar',
      };

      if (mapping[code]) {
        return mapping[code];
      }
    }
  }

  // 3. Default: Indonesia
  return 'id';
}

interface I18nProviderProps {
  children: ReactNode;
  defaultLanguage?: LanguageCode;
}

export function I18nProvider({ children, defaultLanguage }: I18nProviderProps) {
  const [language, setLanguageState] = useState<LanguageCode>(
    () => defaultLanguage || detectBrowserLanguage()
  );

  // Update DOM attribute & RTL direction setiap bahasa berubah
  useEffect(() => {
    const info = getLanguageInfo(language);
    document.documentElement.lang = language;
    document.documentElement.dir = info.rtl ? 'rtl' : 'ltr';
  }, [language]);

  const setLanguage = (code: LanguageCode) => {
    setLanguageState(code);
    try {
      localStorage.setItem(STORAGE_KEY, code);
    } catch {
      // localStorage gak available, skip
    }
  };

  const info = getLanguageInfo(language);
  const value: I18nContextValue = {
    language,
    setLanguage,
    t: TRANSLATIONS[language],
    isRTL: !!info.rtl,
    availableLanguages: LANGUAGES,
  };

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

/**
 * Hook utama buat akses i18n di komponen.
 *
 * Contoh:
 *   const { t, language, setLanguage } = useI18n();
 *   <h1>{t.welcome.greeting}</h1>
 */
export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error('useI18n must be used within <I18nProvider>');
  }
  return ctx;
}

/**
 * Shortcut hook kalau cuma butuh translations doang.
 *
 * Contoh:
 *   const t = useT();
 *   <button>{t.common.save}</button>
 */
export function useT(): Translation {
  return useI18n().t;
}

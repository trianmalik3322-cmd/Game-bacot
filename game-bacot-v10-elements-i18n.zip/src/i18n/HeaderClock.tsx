// 🕐 HeaderClock — Compact clock + greeting di header game
// Auto-update tiap detik, deteksi timezone dari browser

import { useState, useEffect } from 'react';
import { useI18n } from './I18nContext';
import {
  formatTimeShort,
  getDayPeriod,
  getDayPeriodEmoji,
  getGreeting,
  getCountryFlagFromTimezone,
  getUserTimezone,
} from './timeUtils';

interface HeaderClockProps {
  color?: string;
  borderColor?: string;
  compact?: boolean; // ultra-compact mode (hide greeting)
}

export default function HeaderClock({
  color = '#a78bfa',
  borderColor,
  compact = false,
}: HeaderClockProps) {
  const { language } = useI18n();
  const [now, setNow] = useState(() => new Date());

  // Auto-update tiap 1 detik
  useEffect(() => {
    const interval = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const period = getDayPeriod(now);
  const emoji = getDayPeriodEmoji(period);
  const time = formatTimeShort(now, true); // 24h format
  const greeting = getGreeting(period, language);
  const flag = getCountryFlagFromTimezone(getUserTimezone());

  const bColor = borderColor || `${color}55`;
  const bgColor = `${color}22`;

  // Ultra compact: cuma jam + emoji
  if (compact) {
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          background: bgColor,
          border: `1px solid ${bColor}`,
          borderRadius: '8px',
          padding: '3px 8px',
          flexShrink: 0,
        }}
        title={`${greeting} ${flag}`}
      >
        <span style={{ fontSize: '12px' }}>{emoji}</span>
        <span
          style={{
            color,
            fontSize: '10px',
            fontWeight: 700,
            whiteSpace: 'nowrap',
            fontFamily: '"Courier New", monospace',
          }}
        >
          {time}
        </span>
      </div>
    );
  }

  // Normal: emoji + jam + greeting (singkat)
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        background: bgColor,
        border: `1px solid ${bColor}`,
        borderRadius: '8px',
        padding: '3px 8px',
        flexShrink: 0,
      }}
      title={`${greeting} ${flag}`}
    >
      <span style={{ fontSize: '14px' }}>{emoji}</span>
      <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
        <span
          style={{
            color,
            fontSize: '11px',
            fontWeight: 800,
            whiteSpace: 'nowrap',
            fontFamily: '"Courier New", monospace',
          }}
        >
          {time}
        </span>
        <span
          style={{
            color: `${color}cc`,
            fontSize: '8px',
            fontWeight: 600,
            whiteSpace: 'nowrap',
          }}
        >
          {flag} {greeting.length > 14 ? greeting.slice(0, 14) + '…' : greeting}
        </span>
      </div>
    </div>
  );
}

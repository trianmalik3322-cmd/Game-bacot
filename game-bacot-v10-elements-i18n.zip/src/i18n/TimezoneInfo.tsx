// 🌍 TimezoneInfo — Detail panel buat Settings Modal
// Kasih liat jam + tanggal + timezone + greeting (detail)

import { useState, useEffect } from 'react';
import { useI18n } from './I18nContext';
import {
  formatTime,
  formatDate,
  getDayPeriod,
  getDayPeriodEmoji,
  getGreeting,
  getUserTimezone,
  getRegionFromTimezone,
  getCountryFlagFromTimezone,
  getUTCOffset,
  getTimezoneLabel,
  getLocalTimeLabel,
} from './timeUtils';

interface TimezoneInfoProps {
  primaryColor?: string;
  accentColor?: string;
}

export default function TimezoneInfo({
  primaryColor = '#7c3aed',
  accentColor = '#c084fc',
}: TimezoneInfoProps) {
  const { language } = useI18n();
  const [now, setNow] = useState(() => new Date());

  // Auto-update tiap 1 detik
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const tz = getUserTimezone();
  const { city, region } = getRegionFromTimezone(tz);
  const flag = getCountryFlagFromTimezone(tz);
  const offset = getUTCOffset(now);
  const period = getDayPeriod(now);
  const emoji = getDayPeriodEmoji(period);
  const greeting = getGreeting(period, language);

  return (
    <div
      style={{
        background: `linear-gradient(135deg, ${primaryColor}22 0%, ${accentColor}11 100%)`,
        border: `1px solid ${primaryColor}44`,
        borderRadius: '14px',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '14px',
      }}
    >
      {/* Greeting + Period emoji */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
        }}
      >
        <span style={{ fontSize: '36px' }}>{emoji}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p
            style={{
              color: '#fff',
              fontSize: '15px',
              fontWeight: 800,
              margin: 0,
              lineHeight: 1.2,
            }}
          >
            {greeting}! {flag}
          </p>
          <p
            style={{
              color: '#9ca3af',
              fontSize: '11px',
              margin: '3px 0 0',
            }}
          >
            {formatDate(now, language)}
          </p>
        </div>
      </div>

      {/* Big clock */}
      <div
        style={{
          background: 'rgba(0,0,0,0.4)',
          border: `1px solid ${primaryColor}33`,
          borderRadius: '12px',
          padding: '14px',
          textAlign: 'center',
        }}
      >
        <p
          style={{
            color: '#6b7280',
            fontSize: '10px',
            fontWeight: 700,
            textTransform: 'uppercase',
            letterSpacing: '1.5px',
            margin: '0 0 6px',
          }}
        >
          {getLocalTimeLabel(language)}
        </p>
        <p
          style={{
            color: accentColor,
            fontSize: '32px',
            fontWeight: 900,
            margin: 0,
            fontFamily: '"Courier New", monospace',
            letterSpacing: '2px',
            textShadow: `0 0 20px ${accentColor}88`,
          }}
        >
          {formatTime(now, true)}
        </p>
      </div>

      {/* Timezone info */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '8px',
        }}
      >
        {/* Region */}
        <div
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '10px',
            padding: '10px',
          }}
        >
          <p
            style={{
              color: '#6b7280',
              fontSize: '9px',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '1px',
              margin: '0 0 4px',
            }}
          >
            🌍 {getTimezoneLabel(language)}
          </p>
          <p
            style={{
              color: '#fff',
              fontSize: '12px',
              fontWeight: 800,
              margin: 0,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
            title={tz}
          >
            {flag} {city}
          </p>
          <p
            style={{
              color: '#9ca3af',
              fontSize: '10px',
              margin: '2px 0 0',
            }}
          >
            {region}
          </p>
        </div>

        {/* UTC Offset */}
        <div
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: '10px',
            padding: '10px',
          }}
        >
          <p
            style={{
              color: '#6b7280',
              fontSize: '9px',
              fontWeight: 700,
              textTransform: 'uppercase',
              letterSpacing: '1px',
              margin: '0 0 4px',
            }}
          >
            🕐 UTC Offset
          </p>
          <p
            style={{
              color: '#fff',
              fontSize: '12px',
              fontWeight: 800,
              margin: 0,
              fontFamily: '"Courier New", monospace',
            }}
          >
            {offset}
          </p>
          <p
            style={{
              color: '#9ca3af',
              fontSize: '10px',
              margin: '2px 0 0',
            }}
          >
            Auto-detect
          </p>
        </div>
      </div>
    </div>
  );
}

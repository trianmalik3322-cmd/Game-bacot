// 🌐 i18n Public API
// Import everything you need from here:
//   import { useT, useI18n, LanguageSelector, HeaderClock, TimezoneInfo } from './i18n';

export { I18nProvider, useI18n, useT } from './I18nContext';
export { default as LanguageSelector } from './LanguageSelector';
export { default as HeaderClock } from './HeaderClock';
export { default as TimezoneInfo } from './TimezoneInfo';
export {
  LANGUAGES,
  TRANSLATIONS,
  getLanguageInfo,
} from './translations';
export type { LanguageCode, LanguageInfo, Translation } from './translations';

// Time utilities (semua offline-first, pakai browser Date)
export {
  getUserTimezone,
  getRegionFromTimezone,
  getCountryFlagFromTimezone,
  formatTime,
  formatTimeShort,
  formatDate,
  getDayPeriod,
  getDayPeriodEmoji,
  getGreeting,
  getUTCOffset,
  getTimezoneLabel,
  getLocalTimeLabel,
} from './timeUtils';
export type { DayPeriod } from './timeUtils';

export { getElementDesc, ELEMENT_DESCRIPTIONS } from './elementDescriptions';

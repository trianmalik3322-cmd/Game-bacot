// 🕐 Time Utilities — Offline-First (pakai browser Date local)
// Gak butuh API external. Semua deteksi dari browser/HP user.

import type { LanguageCode } from './translations';

/**
 * Dapetin timezone user otomatis (offline, dari browser)
 * Contoh: "Asia/Jakarta", "America/New_York", "Europe/London"
 */
export function getUserTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {
    return 'UTC';
  }
}

/**
 * Dapetin negara/region user dari timezone
 * "Asia/Jakarta" → "Jakarta", "Asia"
 */
export function getRegionFromTimezone(tz: string): { city: string; region: string } {
  const parts = tz.split('/');
  return {
    region: parts[0] || 'Unknown',
    city: (parts[1] || parts[0] || 'Unknown').replace(/_/g, ' '),
  };
}

/**
 * Dapetin bendera emoji dari timezone (best effort)
 * Mapping populer aja, fallback ke 🌍 globe.
 */
export function getCountryFlagFromTimezone(tz: string): string {
  const flagMap: Record<string, string> = {
    // Asia
    'Asia/Jakarta':     '🇮🇩',
    'Asia/Makassar':    '🇮🇩',
    'Asia/Jayapura':    '🇮🇩',
    'Asia/Tokyo':       '🇯🇵',
    'Asia/Shanghai':    '🇨🇳',
    'Asia/Hong_Kong':   '🇭🇰',
    'Asia/Singapore':   '🇸🇬',
    'Asia/Kuala_Lumpur':'🇲🇾',
    'Asia/Bangkok':     '🇹🇭',
    'Asia/Manila':      '🇵🇭',
    'Asia/Seoul':       '🇰🇷',
    'Asia/Taipei':      '🇹🇼',
    'Asia/Kolkata':     '🇮🇳',
    'Asia/Dubai':       '🇦🇪',
    'Asia/Riyadh':      '🇸🇦',
    'Asia/Tehran':      '🇮🇷',
    'Asia/Karachi':     '🇵🇰',
    'Asia/Dhaka':       '🇧🇩',
    'Asia/Ho_Chi_Minh': '🇻🇳',
    // Europe
    'Europe/London':    '🇬🇧',
    'Europe/Paris':     '🇫🇷',
    'Europe/Berlin':    '🇩🇪',
    'Europe/Madrid':    '🇪🇸',
    'Europe/Rome':      '🇮🇹',
    'Europe/Moscow':    '🇷🇺',
    'Europe/Amsterdam': '🇳🇱',
    'Europe/Istanbul':  '🇹🇷',
    // America
    'America/New_York':    '🇺🇸',
    'America/Los_Angeles': '🇺🇸',
    'America/Chicago':     '🇺🇸',
    'America/Denver':      '🇺🇸',
    'America/Toronto':     '🇨🇦',
    'America/Vancouver':   '🇨🇦',
    'America/Mexico_City': '🇲🇽',
    'America/Sao_Paulo':   '🇧🇷',
    'America/Buenos_Aires':'🇦🇷',
    'America/Lima':        '🇵🇪',
    'America/Bogota':      '🇨🇴',
    // Africa
    'Africa/Cairo':        '🇪🇬',
    'Africa/Lagos':        '🇳🇬',
    'Africa/Johannesburg': '🇿🇦',
    'Africa/Nairobi':      '🇰🇪',
    // Oceania
    'Australia/Sydney':    '🇦🇺',
    'Australia/Melbourne': '🇦🇺',
    'Australia/Perth':     '🇦🇺',
    'Pacific/Auckland':    '🇳🇿',
    // Atlantic
    'UTC':                 '🌍',
  };

  return flagMap[tz] || '🌍';
}

/**
 * Format jam: "14:30:25" atau "02:30 PM"
 */
export function formatTime(date: Date, format24h: boolean = true): string {
  if (format24h) {
    return date.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
  }
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

/**
 * Format jam pendek: "14:30" (no seconds)
 */
export function formatTimeShort(date: Date, format24h: boolean = true): string {
  if (format24h) {
    return date.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  }
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

/**
 * Format tanggal: "Senin, 25 Mei 2026"
 * Pakai locale dari LanguageCode user.
 */
export function formatDate(date: Date, lang: LanguageCode): string {
  const localeMap: Record<LanguageCode, string> = {
    id: 'id-ID', en: 'en-US', es: 'es-ES',
    zh: 'zh-CN', ja: 'ja-JP', ar: 'ar-SA',
  };
  try {
    return date.toLocaleDateString(localeMap[lang], {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return date.toLocaleDateString();
  }
}

/**
 * Period of day berdasarkan jam.
 * Returns: 'morning' | 'noon' | 'afternoon' | 'evening' | 'night'
 */
export type DayPeriod = 'morning' | 'noon' | 'afternoon' | 'evening' | 'night';

export function getDayPeriod(date: Date): DayPeriod {
  const h = date.getHours();
  if (h >= 4  && h < 11) return 'morning';   // 04:00-10:59 🌅
  if (h >= 11 && h < 15) return 'noon';      // 11:00-14:59 ☀️
  if (h >= 15 && h < 18) return 'afternoon'; // 15:00-17:59 🌇
  if (h >= 18 && h < 22) return 'evening';   // 18:00-21:59 🌆
  return 'night';                            // 22:00-03:59 🌙
}

/**
 * Emoji buat tiap period of day
 */
export function getDayPeriodEmoji(period: DayPeriod): string {
  return {
    morning:   '🌅',
    noon:      '☀️',
    afternoon: '🌇',
    evening:   '🌆',
    night:     '🌙',
  }[period];
}

/**
 * Greeting per bahasa + period of day
 * Mapping ini gak perlu masuk translations.ts karena standalone
 */
export function getGreeting(period: DayPeriod, lang: LanguageCode): string {
  const greetings: Record<LanguageCode, Record<DayPeriod, string>> = {
    id: {
      morning:   'Selamat Pagi',
      noon:      'Selamat Siang',
      afternoon: 'Selamat Sore',
      evening:   'Selamat Malam',
      night:     'Selamat Malam',
    },
    en: {
      morning:   'Good Morning',
      noon:      'Good Noon',
      afternoon: 'Good Afternoon',
      evening:   'Good Evening',
      night:     'Good Night',
    },
    es: {
      morning:   'Buenos Días',
      noon:      'Buenos Días',
      afternoon: 'Buenas Tardes',
      evening:   'Buenas Tardes',
      night:     'Buenas Noches',
    },
    zh: {
      morning:   '早上好',
      noon:      '中午好',
      afternoon: '下午好',
      evening:   '晚上好',
      night:     '晚安',
    },
    ja: {
      morning:   'おはよう',
      noon:      'こんにちは',
      afternoon: 'こんにちは',
      evening:   'こんばんは',
      night:     'おやすみ',
    },
    ar: {
      morning:   'صباح الخير',
      noon:      'مساء الخير',
      afternoon: 'مساء الخير',
      evening:   'مساء الخير',
      night:     'تصبح على خير',
    },
  };

  return greetings[lang]?.[period] || greetings.en[period];
}

/**
 * Label "Timezone" per bahasa
 */
export function getTimezoneLabel(lang: LanguageCode): string {
  const labels: Record<LanguageCode, string> = {
    id: 'Zona Waktu',
    en: 'Timezone',
    es: 'Zona Horaria',
    zh: '时区',
    ja: 'タイムゾーン',
    ar: 'المنطقة الزمنية',
  };
  return labels[lang] || labels.en;
}

/**
 * Label "Local Time" per bahasa
 */
export function getLocalTimeLabel(lang: LanguageCode): string {
  const labels: Record<LanguageCode, string> = {
    id: 'Waktu Lokal',
    en: 'Local Time',
    es: 'Hora Local',
    zh: '本地时间',
    ja: '現地時間',
    ar: 'الوقت المحلي',
  };
  return labels[lang] || labels.en;
}

/**
 * UTC offset string: "+07:00", "-05:30", dll
 */
export function getUTCOffset(date: Date = new Date()): string {
  const offset = -date.getTimezoneOffset(); // minutes
  const sign = offset >= 0 ? '+' : '-';
  const abs = Math.abs(offset);
  const h = String(Math.floor(abs / 60)).padStart(2, '0');
  const m = String(abs % 60).padStart(2, '0');
  return `UTC${sign}${h}:${m}`;
}
